<#include "mcelements.ftl">
<#include "mcitems.ftl">
new Object() {
	public double evaluate(net.minecraft.world.level.LevelAccessor world) {
		Object _rawX = ${input$x};
		Object _rawZ = ${input$z};
		Object _rawStartY = ${input$start_y};

		int _x = net.minecraft.util.Mth.floor(_rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX)));
		int _z = net.minecraft.util.Mth.floor(_rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ)));
		int _startY = net.minecraft.util.Mth.floor(_rawStartY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawStartY)));
		
		String _dir = "${field$direction}";
		
		int _minBuildY = world.getMinY();
		int _maxBuildY = world.getMaxY() - 1;
		if (_startY < _minBuildY) _startY = _minBuildY;
		if (_startY > _maxBuildY) _startY = _maxBuildY;

		net.minecraft.core.BlockPos.MutableBlockPos _pos = new net.minecraft.core.BlockPos.MutableBlockPos(_x, _startY, _z);
		net.minecraft.world.level.block.Block _targetBlock = ${mappedBlockToBlockStateCode(input$block)}.getBlock();

		if ("UP".equals(_dir)) {
			for (int _y = _startY; _y <= _maxBuildY; _y++) {
				_pos.setY(_y);
				if (world.getBlockState(_pos).is(_targetBlock)) {
					return (double) _y;
				}
			}
		} else if ("DOWN".equals(_dir)) {
			for (int _y = _startY; _y >= _minBuildY; _y--) {
				_pos.setY(_y);
				if (world.getBlockState(_pos).is(_targetBlock)) {
					return (double) _y;
				}
			}
		}
		
		return 999.0d;
	}
}.evaluate(world)