<#include "mcitems.ftl">
if (world instanceof net.minecraft.server.level.ServerLevel _level) {
    net.minecraft.world.item.ItemStack _result = ${mappedMCItemToItemStackCode(input$item, 1)};

    if (!_result.isEmpty()) {
        _result.setCount(Math.max(1, (int) ${input$amount}));

        net.minecraft.core.component.DataComponentType<net.minecraft.world.item.enchantment.ItemEnchantments> _enchantmentComponent =
            net.minecraft.core.component.DataComponents.ENCHANTMENTS;

        net.minecraft.world.item.enchantment.ItemEnchantments _currentEnchants =
            _result.getOrDefault(_enchantmentComponent,
                net.minecraft.world.item.enchantment.ItemEnchantments.EMPTY);

        net.minecraft.world.item.enchantment.ItemEnchantments.Mutable _mutableEnchants =
            new net.minecraft.world.item.enchantment.ItemEnchantments.Mutable(_currentEnchants);

        <#if field$ENCHANT_DATA?? && field$ENCHANT_DATA?has_content && field$ENCHANT_DATA != "[]">
        <#assign enchants = field$ENCHANT_DATA?eval />
        <#list enchants as item>
        <#if item.ench?has_content>
        {
            var _enchHolder${item?index} = _level.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                .get(net.minecraft.resources.Identifier.parse("${item.ench?lower_case}"));

            if (_enchHolder${item?index}.isPresent()) {
                int _levelTarget${item?index} = Math.max(1, (int) ${item.lvl!1});

                <#if item.rand?? && item.rand>
                if (_levelTarget${item?index} > 1) {
                    _levelTarget${item?index} = net.minecraft.util.Mth.nextInt(
                        _level.getRandom(),
                        1,
                        _levelTarget${item?index}
                    );
                }
                </#if>

                _mutableEnchants.set(_enchHolder${item?index}.get(), _levelTarget${item?index});
            }
        }
        </#if>
        </#list>
        </#if>

        _result.set(_enchantmentComponent, _mutableEnchants.toImmutable());

        net.minecraft.world.entity.item.ItemEntity _entityToSpawn =
            new net.minecraft.world.entity.item.ItemEntity(
                _level,
                (double) ${input$x},
                (double) ${input$y},
                (double) ${input$z},
                _result
            );

        _entityToSpawn.setPickUpDelay((int) ${input$delay});

        <#if field$despawn?? && field$despawn == "false">
        _entityToSpawn.setNeverDespawn();
        </#if>

        _level.addFreshEntity(_entityToSpawn);
    }
}