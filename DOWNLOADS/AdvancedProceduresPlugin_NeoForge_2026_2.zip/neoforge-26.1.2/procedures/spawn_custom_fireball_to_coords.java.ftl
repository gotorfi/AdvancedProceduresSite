<#include "mcitems.ftl">

if (world instanceof net.minecraft.world.level.Level _world && !_world.isClientSide()) {
    double _x1 = <#if input$x1?? && input$x1?has_content>${input$x1}<#else>x</#if>;
    double _y1 = <#if input$y1?? && input$y1?has_content>${input$y1}<#else>y</#if>;
    double _z1 = <#if input$z1?? && input$z1?has_content>${input$z1}<#else>z</#if>;

    double _x2 = <#if input$x2?? && input$x2?has_content>${input$x2}<#else>_x1</#if>;
    double _y2 = <#if input$y2?? && input$y2?has_content>${input$y2}<#else>_y1</#if>;
    double _z2 = <#if input$z2?? && input$z2?has_content>${input$z2}<#else>_z1</#if>;

    <#assign shooterEntity = input$shooter!"null">
    net.minecraft.world.entity.LivingEntity _shooterEnt = (${shooterEntity} instanceof net.minecraft.world.entity.LivingEntity _ent) ? _ent : null;
    if (_shooterEnt != null && !<#if input$x1??>true<#else>false</#if>) {
        _x1 = _shooterEnt.getX();
        _y1 = _shooterEnt.getEyeY() - 0.1D;
        _z1 = _shooterEnt.getZ();
    }

    double _dx = _x2 - _x1;
    double _dy = _y2 - _y1;
    double _dz = _z2 - _z1;

    net.minecraft.world.phys.Vec3 _dir = new net.minecraft.world.phys.Vec3(_dx, _dy, _dz).normalize();

    double _inaccuracy = <#if input$inaccuracy?? && input$inaccuracy?has_content>${input$inaccuracy}<#else>0.0</#if>;
    if (_inaccuracy > 0) {
        net.minecraft.util.RandomSource _rnd = _world.getRandom();
        _dir = _dir.add(_rnd.triangle(0.0D, 0.0172275D * _inaccuracy),
                        _rnd.triangle(0.0D, 0.0172275D * _inaccuracy),
                        _rnd.triangle(0.0D, 0.0172275D * _inaccuracy))
                   .normalize();
    }

    double _speed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>1.0</#if>;
    net.minecraft.world.phys.Vec3 _accel = _dir.scale(_speed * 0.1D);

    ${package}.entity.CustomFireballEntity _fireball;

    if (_shooterEnt != null) {
        _fireball = new ${package}.entity.CustomFireballEntity(
            ${package}.entity.CustomFireballEntity.TYPE, 
            _shooterEnt, 
            _accel,
            _world
        );
    } else {
        _fireball = new ${package}.entity.CustomFireballEntity(
            ${package}.entity.CustomFireballEntity.TYPE, 
            _world
        );
        _fireball.setDeltaMovement(_accel);
    }

    _fireball.setPos(_x1, _y1, _z1);

    <#if input$texture?? && input$texture?has_content>
        <#assign texInput = input$texture>
        <#if texInput?contains("ItemStack") || texInput?contains("getUseItem") || texInput?contains("getMainHandItem")>
            _fireball.setCustomTexture(${texInput});
        <#else>
            _fireball.setCustomTexture(new net.minecraft.world.item.ItemStack(${texInput}));
        </#if>
    <#else>
        _fireball.setCustomTexture(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.FIRE_CHARGE));
    </#if>

    double _sizeInput = <#if input$size?? && input$size?has_content>${input$size}<#else>1.0</#if>;
    _fireball.setCustomSize((float) Math.max(0.5D, Math.min(15.0D, _sizeInput)));

    boolean _useGravity = <#if input$useGravity?? && input$useGravity?has_content>${input$useGravity}<#else>false</#if>;
    _fireball.setGravityEnabled(_useGravity);

    <#if field$trailParticle?? && field$trailParticle?has_content>
        <#assign particleVal = field$trailParticle>
        <#if particleVal?starts_with("net.minecraft")>
            _fireball.setTrailParticle(${particleVal});
        <#else>
            _fireball.setTrailParticle(net.minecraft.core.particles.ParticleTypes.${particleVal?upper_case});
        </#if>
    </#if>

    boolean _enableFire = <#if input$enableFire?? && input$enableFire?has_content>${input$enableFire}<#else>true</#if>;

    <#assign expRadius = 0.0>
    <#if field$destroyMode??>
        <#if field$destroyMode == "0"><#assign expRadius = 0.0>
        <#elseif field$destroyMode == "1"><#assign expRadius = 2.0>
        <#elseif field$destroyMode == "2"><#assign expRadius = 4.0>
        <#elseif field$destroyMode == "3"><#assign expRadius = 8.0>
        </#if>
    </#if>

    <#assign fireRad = 0>
    <#if field$fireMode??>
        <#if field$fireMode == "1"><#assign fireRad = 1>
        <#elseif field$fireMode == "2"><#assign fireRad = 3>
        <#elseif field$fireMode == "3"><#assign fireRad = 5>
        <#elseif field$fireMode == "4"><#assign fireRad = 8>
        </#if>
    </#if>

    _fireball.setExplosionParams(${expRadius}f, ${fireRad}, _enableFire);
    _world.addFreshEntity(_fireball);
}