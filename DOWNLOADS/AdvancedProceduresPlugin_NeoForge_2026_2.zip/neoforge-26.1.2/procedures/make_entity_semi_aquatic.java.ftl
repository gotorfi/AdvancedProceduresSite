<#include "mcitems.ftl">
if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    if (_mob.isInWater()) {
        double _swimSpeed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>0.12D</#if>;

        _mob.setAirSupply(_mob.getMaxAirSupply());
        _mob.setJumping(false);

        _mob.goalSelector.getAvailableGoals().removeIf(_wrappedGoal -> 
            _wrappedGoal.getGoal() instanceof net.minecraft.world.entity.ai.goal.FloatGoal
        );

        if (!(_mob.getNavigation() instanceof net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation)) {
            try {
                java.lang.reflect.Field _navField = net.minecraft.world.entity.Mob.class.getDeclaredField("navigation");
                _navField.setAccessible(true);
                _navField.set(_mob, new net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation(_mob, _mob.level()));
            } catch (Exception _e) {
            }
        }
        
        if (_mob instanceof net.minecraft.world.entity.monster.zombie.Zombie _zombie) {
            try {
                java.lang.reflect.Field _convField = net.minecraft.world.entity.monster.zombie.Zombie.class.getDeclaredField("conversionTime");
                _convField.setAccessible(true);
                _convField.setInt(_zombie, -1);
                
                java.lang.reflect.Field _waterField = net.minecraft.world.entity.monster.zombie.Zombie.class.getDeclaredField("inWaterTime");
                _waterField.setAccessible(true);
                _waterField.setInt(_zombie, 0);
            } catch (Exception _e) {
            }
        }

        if (_mob.isSwimming() || _mob.getPose() == net.minecraft.world.entity.Pose.SWIMMING) {
            _mob.setSwimming(false);
            _mob.setPose(net.minecraft.world.entity.Pose.STANDING);
        }

        net.minecraft.world.entity.LivingEntity _target = _mob.getTarget();

        if (_target != null && _target.isAlive()) {
            double _dx = _target.getX() - _mob.getX();
            double _dy = _target.getEyeY() - _mob.getEyeY();
            double _dz = _target.getZ() - _mob.getZ();
            
            double _horizontalDist = Math.sqrt(_dx * _dx + _dz * _dz);

            if (_horizontalDist > 1.0E-5D || Math.abs(_dy) > 1.0E-5D) {
                float _yRotD = (float) (Math.atan2(_dz, _dx) * (180.0D / Math.PI)) - 90.0F;
                float _xRotD = -((float) (Math.atan2(_dy, _horizontalDist) * (180.0D / Math.PI)));

                float _currentY = _mob.getYRot();
                float _diffY = net.minecraft.util.Mth.wrapDegrees(_yRotD - _currentY);
                float _newY = _currentY + net.minecraft.util.Mth.clamp(_diffY, -10.0F, 10.0F);

                _mob.setYRot(_newY);
                _mob.setXRot(net.minecraft.util.Mth.clamp(_xRotD, -30.0F, 30.0F));
                
                _mob.yHeadRot = _newY;
                _mob.yBodyRot = _newY;
                _mob.yRotO = _newY;
                _mob.xRotO = _mob.getXRot();
            }

            double _totalDist = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
            if (_totalDist > 0.001D) {
                net.minecraft.world.phys.Vec3 _currentMotion = _mob.getDeltaMovement();
                
                double _vx = (_dx / _totalDist) * _swimSpeed;
                double _vy = (_dy / _totalDist) * _swimSpeed;
                double _vz = (_dz / _totalDist) * _swimSpeed;

                _mob.setDeltaMovement(
                    _currentMotion.x * 0.2D + _vx * 0.8D,
                    _vy - 0.03D,
                    _currentMotion.z * 0.2D + _vz * 0.8D
                );
            }
        } else {
            net.minecraft.world.phys.Vec3 _motion = _mob.getDeltaMovement();
            _mob.setDeltaMovement(_motion.x * 0.8D, -0.08D, _motion.z * 0.8D);
        }
    }
}