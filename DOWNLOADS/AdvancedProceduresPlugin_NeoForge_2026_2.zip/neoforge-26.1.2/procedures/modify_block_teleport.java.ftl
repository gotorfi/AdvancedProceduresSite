<#include "mcelements.ftl">
<#include "mcitems.ftl">
<#assign sound = generator.map(field$sound!"portal", "sounds")?replace("CUSTOM:", "${modid}:")?lower_case>
<#assign particleRaw = generator.map(field$particle!"portal", "particles")>
<#assign particle = particleRaw?replace("ParticleTypes.", "")?replace("CUSTOM:", "${modid}:")?lower_case>

if (world instanceof net.minecraft.server.level.ServerLevel _level) {
	net.minecraft.core.BlockPos _pos = ${toBlockPos(input$x, input$y, input$z)};
	if (${input$enabled}) {
		net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> _targetDim = ${generator.map(field$dimension, "dimensions")};
		
		net.minecraft.resources.Identifier _soundId = net.minecraft.resources.Identifier.parse("${sound}");
		net.minecraft.sounds.SoundEvent _soundEvt = net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.getValue(_soundId);
		
		net.minecraft.resources.Identifier _partId = net.minecraft.resources.Identifier.parse("${particle}");
		net.minecraft.core.particles.ParticleOptions _partOpt = (net.minecraft.core.particles.ParticleOptions) net.minecraft.core.registries.BuiltInRegistries.PARTICLE_TYPE.getValue(_partId);
		
		int _ticks = (int) (${opt.toDouble(input$seconds)} * 20);
		int _offsetY = (int) ${opt.toDouble(input$trigger_offset_y)};

		${package}.world.TeleportBlockHandler.registerPortal(
			_level, 
			_level.dimension(), 
			_pos, 
			_targetDim, 
			${opt.toDouble(input$target_x)}, 
			${opt.toDouble(input$target_y)}, 
			${opt.toDouble(input$target_z)}, 
			_soundEvt, 
			_partOpt, 
			_ticks, 
			_offsetY
		);
	} else {
		${package}.world.TeleportBlockHandler.unregisterPortal(
			_level,
			_level.dimension(),
			_pos
		);
	}
}