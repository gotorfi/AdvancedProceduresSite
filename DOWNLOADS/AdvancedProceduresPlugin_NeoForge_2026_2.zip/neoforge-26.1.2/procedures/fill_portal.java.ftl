<#include "mcitems.ftl">
if (world instanceof net.minecraft.world.level.LevelAccessor _world) {
	Object _rawX = (double) ${input$x};
	Object _rawY = (double) ${input$y};
	Object _rawZ = (double) ${input$z};

	int _clickX = net.minecraft.util.Mth.floor(_rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX)));
	int _clickY = net.minecraft.util.Mth.floor(_rawY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY)));
	int _clickZ = net.minecraft.util.Mth.floor(_rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ)));

	net.minecraft.world.level.block.Block _fillBlock = ${mappedBlockToBlock(input$block)};
	net.minecraft.world.level.block.state.BlockState _fillState = _fillBlock.defaultBlockState();
	String _pType = "${field$portal_type}";

	java.util.function.BiPredicate<net.minecraft.world.level.LevelAccessor, net.minecraft.core.BlockPos> _isEmpty = (_lvl, _p) -> {
		net.minecraft.world.level.block.state.BlockState _bs = _lvl.getBlockState(_p);
		return _bs.isAir() || _bs.canBeReplaced();
	};

	net.minecraft.core.BlockPos.MutableBlockPos _pos = new net.minecraft.core.BlockPos.MutableBlockPos();
	net.minecraft.core.BlockPos _clickPos = new net.minecraft.core.BlockPos(_clickX, _clickY, _clickZ);

	java.util.List<net.minecraft.core.BlockPos> _airCandidates = new java.util.ArrayList<>();
	if (_isEmpty.test(_world, _clickPos)) {
		_airCandidates.add(_clickPos);
	} else {
		for (net.minecraft.core.Direction _dir : net.minecraft.core.Direction.values()) {
			net.minecraft.core.BlockPos _adjacent = _clickPos.relative(_dir);
			if (_isEmpty.test(_world, _adjacent)) {
				_airCandidates.add(_adjacent);
			}
		}
	}

	boolean _filled = false;

	for (net.minecraft.core.BlockPos _airStart : _airCandidates) {
		if (_filled) break;

		if ("NETHER".equals(_pType)) {
			for (int _axis = 0; _axis < 2; _axis++) {
				boolean _xDir = (_axis == 0);

				int _sX = _airStart.getX();
				int _sY = _airStart.getY();
				int _sZ = _airStart.getZ();

				while (_sY > _world.getMinY() && _isEmpty.test(_world, _pos.set(_sX, _sY - 1, _sZ))) {
					_sY--;
				}

				int _walkLeft = 0;
				while (_isEmpty.test(_world, _pos.set(_xDir ? _sX - 1 : _sX, _sY, _xDir ? _sZ : _sZ - 1))) {
					if (_xDir) _sX--; else _sZ--;
					_walkLeft++;
					if (_walkLeft > 21) break;
				}

				int _actualW = 0;
				while (_isEmpty.test(_world, _pos.set(_xDir ? _sX + _actualW : _sX, _sY, _xDir ? _sZ : _sZ + _actualW))) {
					_actualW++;
					if (_actualW > 22) break;
				}

				int _actualH = 0;
				while (_isEmpty.test(_world, _pos.set(_sX, _sY + _actualH, _sZ))) {
					_actualH++;
					if (_actualH > 22) break;
				}

				if (_actualW >= 1 && _actualW <= 21 && _actualH >= 1 && _actualH <= 21) {
					net.minecraft.world.level.block.state.BlockState _orientedState = _fillState;
					var _axisProp = _fillState.getBlock().getStateDefinition().getProperty("axis");
					if (_axisProp instanceof net.minecraft.world.level.block.state.properties.EnumProperty _ep) {
						net.minecraft.core.Direction.Axis _targetAxis = _xDir ? net.minecraft.core.Direction.Axis.X : net.minecraft.core.Direction.Axis.Z;
						if (_ep.getPossibleValues().contains(_targetAxis)) {
							_orientedState = (net.minecraft.world.level.block.state.BlockState) _fillState.setValue(_ep, _targetAxis);
						}
					}

					for (int _w = 0; _w < _actualW; _w++) {
						for (int _h = 0; _h < _actualH; _h++) {
							_pos.set(_xDir ? _sX + _w : _sX, _sY + _h, _xDir ? _sZ : _sZ + _w);
							_world.setBlock(_pos, _orientedState, 3);
						}
					}
					_filled = true;
					break;
				}
			}
		} else if ("END".equals(_pType)) {
			int _sX = _airStart.getX();
			int _sY = _airStart.getY();
			int _sZ = _airStart.getZ();

			int _walkX = 0;
			while (_isEmpty.test(_world, _pos.set(_sX - 1, _sY, _sZ))) {
				_sX--;
				_walkX++;
				if (_walkX > 21) break;
			}

			int _walkZ = 0;
			while (_isEmpty.test(_world, _pos.set(_sX, _sY, _sZ - 1))) {
				_sZ--;
				_walkZ++;
				if (_walkZ > 21) break;
			}

			int _actualW = 0;
			while (_isEmpty.test(_world, _pos.set(_sX + _actualW, _sY, _sZ))) {
				_actualW++;
				if (_actualW > 22) break;
			}

			int _actualH = 0;
			while (_isEmpty.test(_world, _pos.set(_sX, _sY, _sZ + _actualH))) {
				_actualH++;
				if (_actualH > 22) break;
			}

			if (_actualW >= 1 && _actualW <= 21 && _actualH >= 1 && _actualH <= 21) {
				for (int _w = 0; _w < _actualW; _w++) {
					for (int _h = 0; _h < _actualH; _h++) {
						_pos.set(_sX + _w, _sY, _sZ + _h);
						_world.setBlock(_pos, _fillState, 3);
					}
				}
				_filled = true;
				break;
			}
		}
	}
}