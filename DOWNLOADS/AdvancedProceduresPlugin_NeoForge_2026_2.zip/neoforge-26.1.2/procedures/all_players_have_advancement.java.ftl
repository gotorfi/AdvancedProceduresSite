(new Object() {
	public boolean check(net.minecraft.world.level.LevelAccessor _world) {
		if (_world instanceof ServerLevel _level) {
			AdvancementHolder _adv = _level.getServer().getAdvancements().get(Identifier.parse(${input$advancement}));
			if (_adv != null) {
				java.util.List<ServerPlayer> _players = _level.getServer().getPlayerList().getPlayers();
				if (_players.isEmpty()) return false;
				for (ServerPlayer _player : _players) {
					if (!_player.getAdvancements().getOrStartProgress(_adv).isDone()) {
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}
}.check(world))