if (${input$entity} != null && world instanceof net.minecraft.server.level.ServerLevel _level) {
    String _structId = ${input$structure};
    net.minecraft.core.BlockPos _entityPos = ${input$entity}.blockPosition();
    net.minecraft.resources.Identifier _structLoc = net.minecraft.resources.Identifier.tryParse(_structId);
    
    if (_structLoc != null) {
        var _registry = _level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.STRUCTURE);
        net.minecraft.resources.ResourceKey<net.minecraft.world.level.levelgen.structure.Structure> _structKey = 
            net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.STRUCTURE, _structLoc);
            
        var _holder = _registry.get(_structKey);
        if (_holder.isPresent()) {
            net.minecraft.core.HolderSet<net.minecraft.world.level.levelgen.structure.Structure> _holderSet = 
                net.minecraft.core.HolderSet.direct(_holder.get());
                
            var _chunkGenerator = _level.getChunkSource().getGenerator();
            var _pair = _chunkGenerator.findNearestMapStructure(_level, _holderSet, _entityPos, 500, false);
            
            if (_pair != null) {
                net.minecraft.core.BlockPos _targetPos = _pair.getFirst();
                
                net.minecraft.world.item.ItemStack _mapStack = net.minecraft.world.item.MapItem.create(_level, 
                    _targetPos.getX(), _targetPos.getZ(), (byte) 2, true, true);
                
                net.minecraft.world.item.MapItem.renderBiomePreviewMap(_level, _mapStack);
                net.minecraft.world.level.saveddata.maps.MapItemSavedData.addTargetDecoration(_mapStack, _targetPos, "+", 
                    net.minecraft.world.level.saveddata.maps.MapDecorationTypes.RED_X);
                
                if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _livingEntity) {
                    _livingEntity.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, _mapStack);
                }
            }
        }
    }
}