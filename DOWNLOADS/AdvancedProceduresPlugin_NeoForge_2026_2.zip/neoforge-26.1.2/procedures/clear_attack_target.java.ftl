if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobClearTask) {
    net.minecraft.nbt.CompoundTag _pd = _mobClearTask.getPersistentData();
    _pd.remove("blockLock");
    _pd.remove("targetBlockX");
    _pd.remove("targetBlockY");
    _pd.remove("targetBlockZ");
    _pd.putBoolean("abandonBlockTask", true);

    _mobClearTask.goalSelector.getAvailableGoals().removeIf(wrappedGoal -> 
        wrappedGoal.getGoal() instanceof ${package}.ai.MoveToStructureGoal ||
        wrappedGoal.getGoal() instanceof ${package}.ai.OverrideMovementGoal
    );

    _mobClearTask.setNoGravity(false);
    _mobClearTask.setTarget(null);
    _mobClearTask.getNavigation().stop();
}