<#include "mcelements.ftl">
<#include "mcitems.ftl">
(new Object() {
	public boolean check(net.minecraft.world.level.LevelAccessor world) {
		Object _rawX = ${input$x};
		Object _rawY = ${input$y};
		Object _rawZ = ${input$z};

		int _clickX = net.minecraft.util.Mth.floor(_rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX)));
		int _clickY = net.minecraft.util.Mth.floor(_rawY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY)));
		int _clickZ = net.minecraft.util.Mth.floor(_rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ)));

		Object _rawMinW = ${input$min_width};
		Object _rawMinH = ${input$min_height};
		Object _rawMaxW = ${input$max_width};
		Object _rawMaxH = ${input$max_height};
		Object _rawBS = ${input$blockstate};

		int _minW = Math.max(1, net.minecraft.util.Mth.floor(_rawMinW instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawMinW))));
		int _minH = Math.max(1, net.minecraft.util.Mth.floor(_rawMinH instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawMinH))));
		int _maxW = Math.max(_minW, net.minecraft.util.Mth.floor(_rawMaxW instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawMaxW))));
		int _maxH = Math.max(_minH, net.minecraft.util.Mth.floor(_rawMaxH instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawMaxH))));
		int _targetBS = net.minecraft.util.Mth.floor(_rawBS instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawBS)));

		net.minecraft.world.level.block.Block _reqBlock = ${mappedBlockToBlockStateCode(input$block)}.getBlock();
		String _pType = "${field$portal_type}";

		java.util.function.BiPredicate<net.minecraft.world.level.LevelAccessor, net.minecraft.core.BlockPos> _isValidFrame = (_lvl, _p) -> {
			net.minecraft.world.level.block.state.BlockState _bs = _lvl.getBlockState(_p);
			if (!_bs.is(_reqBlock)) return false;
			if (_targetBS >= 0) {
				var _prop = _bs.getBlock().getStateDefinition().getProperty("blockstate");
				if (_prop instanceof net.minecraft.world.level.block.state.properties.IntegerProperty _ip) {
					return _bs.getValue(_ip) == _targetBS;
				}
				return false;
			}
			return true;
		};

		java.util.function.BiPredicate<net.minecraft.world.level.LevelAccessor, net.minecraft.core.BlockPos> _isEmpty = (_lvl, _p) -> {
			net.minecraft.world.level.block.state.BlockState _bs = _lvl.getBlockState(_p);
			return _bs.isAir() || _bs.canBeReplaced();
		};

		net.minecraft.core.BlockPos.MutableBlockPos _pos = new net.minecraft.core.BlockPos.MutableBlockPos();
		net.minecraft.core.BlockPos _clickPos = new net.minecraft.core.BlockPos(_clickX, _clickY, _clickZ);

		java.util.List<net.minecraft.core.BlockPos> _airCandidates = new java.util.ArrayList<>();
		if (_isEmpty.test(world, _clickPos)) {
			_airCandidates.add(_clickPos);
		} else {
			for (net.minecraft.core.Direction _dir : net.minecraft.core.Direction.values()) {
				net.minecraft.core.BlockPos _adjacent = _clickPos.relative(_dir);
				if (_isEmpty.test(world, _adjacent)) {
					_airCandidates.add(_adjacent);
				}
			}
		}

		if (_airCandidates.isEmpty()) return false;

		for (net.minecraft.core.BlockPos _airStart : _airCandidates) {
			if ("NETHER".equals(_pType)) {
				for (int _axis = 0; _axis < 2; _axis++) {
					boolean _xDir = (_axis == 0);

					int _sX = _airStart.getX();
					int _sY = _airStart.getY();
					int _sZ = _airStart.getZ();

					while (_sY > world.getMinY() && _isEmpty.test(world, _pos.set(_sX, _sY - 1, _sZ))) {
						_sY--;
					}

					int _walkLeft = 0;
					while (_isEmpty.test(world, _pos.set(_xDir ? _sX - 1 : _sX, _sY, _xDir ? _sZ : _sZ - 1))) {
						if (_xDir) _sX--; else _sZ--;
						_walkLeft++;
						if (_walkLeft > _maxW) break;
					}

					int _actualW = 0;
					while (_isEmpty.test(world, _pos.set(_xDir ? _sX + _actualW : _sX, _sY, _xDir ? _sZ : _sZ + _actualW))) {
						_actualW++;
						if (_actualW > _maxW + 1) break;
					}

					int _actualH = 0;
					while (_isEmpty.test(world, _pos.set(_sX, _sY + _actualH, _sZ))) {
						_actualH++;
						if (_actualH > _maxH + 1) break;
					}

					if (_actualW < _minW || _actualW > _maxW || _actualH < _minH || _actualH > _maxH) {
						continue;
					}

					boolean _valid = true;

					for (int _w = 0; _w < _actualW; _w++) {
						for (int _h = 0; _h < _actualH; _h++) {
							if (!_isEmpty.test(world, _pos.set(_xDir ? _sX + _w : _sX, _sY + _h, _xDir ? _sZ : _sZ + _w))) {
								_valid = false;
								break;
							}
						}
						if (!_valid) break;
					}
					if (!_valid) continue;

					for (int _w = 0; _w < _actualW; _w++) {
						if (!_isValidFrame.test(world, _pos.set(_xDir ? _sX + _w : _sX, _sY - 1, _xDir ? _sZ : _sZ + _w))) { _valid = false; break; }
						if (!_isValidFrame.test(world, _pos.set(_xDir ? _sX + _w : _sX, _sY + _actualH, _xDir ? _sZ : _sZ + _w))) { _valid = false; break; }
					}
					if (!_valid) continue;

					for (int _h = 0; _h < _actualH; _h++) {
						if (!_isValidFrame.test(world, _pos.set(_xDir ? _sX - 1 : _sX, _sY + _h, _xDir ? _sZ : _sZ - 1))) { _valid = false; break; }
						if (!_isValidFrame.test(world, _pos.set(_xDir ? _sX + _actualW : _sX, _sY + _h, _xDir ? _sZ : _sZ + _actualW))) { _valid = false; break; }
					}

					if (_valid) return true;
				}
			} else if ("END".equals(_pType)) {
				int _sX = _airStart.getX();
				int _sY = _airStart.getY();
				int _sZ = _airStart.getZ();

				int _walkX = 0;
				while (_isEmpty.test(world, _pos.set(_sX - 1, _sY, _sZ))) {
					_sX--;
					_walkX++;
					if (_walkX > _maxW) break;
				}

				int _walkZ = 0;
				while (_isEmpty.test(world, _pos.set(_sX, _sY, _sZ - 1))) {
					_sZ--;
					_walkZ++;
					if (_walkZ > _maxH) break;
				}

				int _actualW = 0;
				while (_isEmpty.test(world, _pos.set(_sX + _actualW, _sY, _sZ))) {
					_actualW++;
					if (_actualW > _maxW + 1) break;
				}

				int _actualH = 0;
				while (_isEmpty.test(world, _pos.set(_sX, _sY, _sZ + _actualH))) {
					_actualH++;
					if (_actualH > _maxH + 1) break;
				}

				if (_actualW < _minW || _actualW > _maxW || _actualH < _minH || _actualH > _maxH) {
					continue;
				}

				boolean _valid = true;

				for (int _w = 0; _w < _actualW; _w++) {
					for (int _h = 0; _h < _actualH; _h++) {
						if (!_isEmpty.test(world, _pos.set(_sX + _w, _sY, _sZ + _h))) {
							_valid = false;
							break;
						}
					}
					if (!_valid) break;
				}
				if (!_valid) continue;

				for (int _w = 0; _w < _actualW; _w++) {
					if (!_isValidFrame.test(world, _pos.set(_sX + _w, _sY, _sZ - 1))) { _valid = false; break; }
					if (!_isValidFrame.test(world, _pos.set(_sX + _w, _sY, _sZ + _actualH))) { _valid = false; break; }
				}
				if (!_valid) continue;

				for (int _h = 0; _h < _actualH; _h++) {
					if (!_isValidFrame.test(world, _pos.set(_sX - 1, _sY, _sZ + _h))) { _valid = false; break; }
					if (!_isValidFrame.test(world, _pos.set(_sX + _actualW, _sY, _sZ + _h))) { _valid = false; break; }
				}

				if (_valid) return true;
			}
		}

		return false;
	}
}.check(world))