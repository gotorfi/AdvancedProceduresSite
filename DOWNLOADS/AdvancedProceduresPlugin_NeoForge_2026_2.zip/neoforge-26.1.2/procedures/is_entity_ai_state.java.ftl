(${input$entity} != null ? (
    "${field$mode}".equals("HasImmunity") ? ${input$entity}.isInvulnerable() :
    (${input$entity} instanceof net.minecraft.world.entity.Mob _mob ? (
        "${field$mode}".equals("IsFrozen") ? _mob.isNoAi() : 
        "${field$mode}".equals("Brainless") ? _mob.goalSelector.getAvailableGoals().isEmpty() : 
        "${field$mode}".equals("HasCustomTask") ? (
            _mob.getPersistentData().contains("blockLock") ||
            _mob.getPersistentData().contains("targetBlockX") ||
            _mob.getPersistentData().contains("orbitCenterX") ||
            _mob.goalSelector.getAvailableGoals().stream().anyMatch(_g -> 
                _g.getGoal() instanceof ${package}.ai.MoveToBlockGoal ||
                _g.getGoal() instanceof ${package}.ai.MoveToStructureGoal ||
                _g.getGoal() instanceof ${package}.ai.OverrideMovementGoal ||
                _g.getGoal() instanceof ${package}.ai.OrbitPositionGoal
            )
        ) :
        false
    ) : false)
) : false)