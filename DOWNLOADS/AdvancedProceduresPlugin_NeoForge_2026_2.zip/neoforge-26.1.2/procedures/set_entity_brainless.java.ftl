if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobBrainless) {
    net.minecraft.resources.Identifier _modifierId = net.minecraft.resources.Identifier.fromNamespaceAndPath("${modid}", "brainless_stay");

    if (${input$state}) {
        _mobBrainless.goalSelector.removeAllGoals(_g -> true);
        _mobBrainless.targetSelector.removeAllGoals(_g -> true);
        _mobBrainless.getLookControl().setLookAt(_mobBrainless.getX(), _mobBrainless.getEyeY(), _mobBrainless.getZ(), 0.0F, 0.0F);
        
        if (${input$stay}) {
            _mobBrainless.setDeltaMovement(0.0d, _mobBrainless.getDeltaMovement().y, 0.0d);
            _mobBrainless.setXxa(0.0F);
            _mobBrainless.setYya(0.0F);
            _mobBrainless.setZza(0.0F);
            _mobBrainless.setSpeed(0.0F);

            net.minecraft.world.entity.ai.attributes.AttributeInstance _kb = _mobBrainless.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
            if (_kb != null) {
                _kb.removeModifier(_modifierId);

                _kb.addPermanentModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(
                    _modifierId, 
                    1.0D, 
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_VALUE
                ));
            }
            
            _mobBrainless.getPersistentData().putBoolean("BrainlessStayActive", true);
        }
    } else {
        _mobBrainless.goalSelector.removeAllGoals(_g -> true);
        _mobBrainless.targetSelector.removeAllGoals(_g -> true);

        net.minecraft.world.entity.ai.attributes.AttributeInstance _kb = _mobBrainless.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
        if (_kb != null) {
            _kb.removeModifier(_modifierId);
        }
        _mobBrainless.getPersistentData().putBoolean("BrainlessStayActive", false);
        
        try {
            java.lang.reflect.Method _m = net.minecraft.world.entity.Mob.class.getDeclaredMethod("registerGoals");
            _m.setAccessible(true);
            _m.invoke(_mobBrainless);
        } catch (Exception _e) {
            // fail
        }
    }
}