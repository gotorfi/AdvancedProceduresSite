<#include "procedures.java.ftl">
@EventBusSubscriber public class ${name}Procedure {
	@SubscribeEvent public static void onExplosionDetonate(net.neoforged.neoforge.event.level.ExplosionEvent.Detonate event) {
		if (event != null && event.getLevel() != null) {
			net.minecraft.world.level.Level level = (net.minecraft.world.level.Level) event.getLevel();
			net.minecraft.world.phys.Vec3 pos = event.getExplosion().center();
			
			net.minecraft.world.entity.Entity exploder = event.getExplosion().getDirectSourceEntity();
			if (exploder == null) {
				exploder = event.getExplosion().getIndirectSourceEntity();
			}

			net.minecraft.world.level.block.state.BlockState sourceBlock = net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();


			if (exploder instanceof net.minecraft.world.entity.item.PrimedTnt) {
				sourceBlock = net.minecraft.world.level.block.Blocks.TNT.defaultBlockState();
			} 
			else if (exploder instanceof net.minecraft.world.entity.vehicle.minecart.MinecartTNT) {
				sourceBlock = net.minecraft.world.level.block.Blocks.TNT.defaultBlockState();
			} 
			else {
				net.minecraft.core.BlockPos blockPos = net.minecraft.core.BlockPos.containing(pos);
				net.minecraft.world.level.block.state.BlockState stateAtPos = level.getBlockState(blockPos);
				if (!stateAtPos.isAir()) {
					sourceBlock = stateAtPos;
				}
			}

			<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"x": "pos.x()",
				"y": "pos.y()",
				"z": "pos.z()",
				"world": "level",
				"entity": "exploder",
				"blockstate": "sourceBlock",
				"event": "event"
			}/>
			</#compress></#assign>
			execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
		}
	}