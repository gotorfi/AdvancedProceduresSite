<#include "mcitems.ftl">

if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobClearTask) {
	net.minecraft.nbt.CompoundTag _pd = _mobClearTask.getPersistentData();
	_pd.remove("blockLock");
	_pd.remove("targetBlockX");
	_pd.remove("targetBlockY");
	_pd.remove("targetBlockZ");
	_pd.remove("orbitCenterX");
	_pd.remove("orbitCenterY");
	_pd.remove("orbitCenterZ");
	_pd.putBoolean("abandonBlockTask", true);

	_mobClearTask.goalSelector.getAvailableGoals().removeIf(wrappedGoal -> 
		wrappedGoal.getGoal() instanceof ${package}.ai.MoveToBlockGoal ||
		wrappedGoal.getGoal() instanceof ${package}.ai.MoveToStructureGoal ||
		wrappedGoal.getGoal() instanceof ${package}.ai.OverrideMovementGoal ||
		wrappedGoal.getGoal() instanceof ${package}.ai.OrbitPositionGoal
	);

	_mobClearTask.setNoGravity(false);
	_mobClearTask.setTarget(null);
	_mobClearTask.getNavigation().stop();
}