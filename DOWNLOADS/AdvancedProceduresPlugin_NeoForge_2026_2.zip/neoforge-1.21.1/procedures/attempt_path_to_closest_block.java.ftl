<#include "mcitems.ftl">
if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    <#assign mode = field$MODE!"PRIORITY_LOCK">
    <#assign getInside = (field$INSIDE!"false") == "TRUE" || (field$INSIDE!"false") == "true">
    
    net.minecraft.world.item.Item _targetItem = ${mappedMCItemToItem(input$block)};
    if (_targetItem instanceof net.minecraft.world.item.BlockItem _blockItem) {
        net.minecraft.world.level.block.Block _targetBlock = _blockItem.getBlock();
        
        _mob.getPersistentData().putBoolean("abandonBlockTask", false);
        
        _mob.goalSelector.getAvailableGoals().removeIf(_wrapped -> _wrapped.getGoal() instanceof ${package}.ai.MoveToBlockGoal);
        
        _mob.goalSelector.addGoal(1, new ${package}.ai.MoveToBlockGoal(
            _mob, 
            _targetBlock, 
            "${mode}", 
            ${getInside?string("true", "false")}, 
            1.2D
        ));
    }
}