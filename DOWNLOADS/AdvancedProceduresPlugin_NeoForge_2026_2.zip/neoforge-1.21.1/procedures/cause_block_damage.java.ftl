<#include "mcitems.ftl">
if (world instanceof net.minecraft.server.level.ServerLevel _level) {
	net.minecraft.core.BlockPos _pos = net.minecraft.core.BlockPos.containing(((Number) ${input$x}).doubleValue(), ((Number) ${input$y}).doubleValue(), ((Number) ${input$z}).doubleValue());
	double _dmg = <#if input$damage?? && input$damage?has_content>${input$damage}<#else>10</#if>;
	boolean _drop = <#if input$drop?? && input$drop?has_content>${input$drop}<#else>true</#if>;
	int _rec = (int) <#if input$recover?? && input$recover?has_content>${input$recover}<#else>5</#if>;

	${package}.world.BlockDamageHandler.applyDamage(_level, _pos, _dmg, _rec, _drop);
}