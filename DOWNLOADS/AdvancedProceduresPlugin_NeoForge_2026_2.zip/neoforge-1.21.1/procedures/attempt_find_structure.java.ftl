<#include "mcitems.ftl">
if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    _mob.getPersistentData().putBoolean("abandonBlockTask", false);
    <#if input$structure?? && input$structure?has_content>
        String _structInput = ${input$structure};
    <#else>
        String _structInput = "minecraft:village_plains";
    </#if>

    double _speed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>1.0D</#if>;
    _mob.goalSelector.addGoal(1, new ${package}.ai.MoveToStructureGoal(_mob, _structInput, _speed, "${modid}"));
}