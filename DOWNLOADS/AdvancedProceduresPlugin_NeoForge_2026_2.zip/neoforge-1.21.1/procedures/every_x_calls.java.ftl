<#-- @formatter:off -->
<#assign interval_val = input$interval!"20">
<#assign code_str = statement$do!"">
<#assign unique_id = "counter_" + code_str?length + "_" + code_str?html?length>
<#if entity??>
if (!${entity}.level().isClientSide()) {
	if (${package}.math.CallCounter.shouldExecute("${unique_id}", (long) ${interval_val}, ${entity}.level().getGameTime())) {
		${statement$do!}
	}
}
<#elseif world??>
if (${world} instanceof net.minecraft.server.level.ServerLevel _serverLevel) {
	if (${package}.math.CallCounter.shouldExecute("${unique_id}", (long) ${interval_val}, _serverLevel.getGameTime())) {
		${statement$do!}
	}
}
<#else>
if (net.neoforged.neoforge.server.ServerLifecycleHooks.getCurrentServer() != null) {
	long _currentTime = net.neoforged.neoforge.server.ServerLifecycleHooks.getCurrentServer().overworld().getGameTime();
	if (${package}.math.CallCounter.shouldExecute("${unique_id}", (long) ${interval_val}, _currentTime)) {
		${statement$do!}
	}
}
</#if>
<#-- @formatter:on -->