<#include "mcitems.ftl">

if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobOrbit) {
    _mobOrbit.getPersistentData().putBoolean("abandonBlockTask", false);

    double _cx = <#if input$x?? && input$x?has_content>${input$x}<#else>x</#if>;
    double _cy = <#if input$y?? && input$y?has_content>${input$y}<#else>y</#if>;
    double _cz = <#if input$z?? && input$z?has_content>${input$z}<#else>z</#if>;
    double _speed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>1.0</#if>;
    double _radius = <#if input$radius?? && input$radius?has_content>${input$radius}<#else>3.0</#if>;
    double _tiltAngle = <#if input$angle?? && input$angle?has_content>${input$angle}<#else>0.0</#if>;
    double _dynamicRotSpeed = <#if input$dynamicRotSpeed?? && input$dynamicRotSpeed?has_content>${input$dynamicRotSpeed}<#else>0.0</#if>;
    int _stopCondition = ${field$stopCondition!"0"};

    _mobOrbit.goalSelector.getAvailableGoals().removeIf(wrappedGoal -> 
        wrappedGoal.getGoal() instanceof ${package}.ai.OrbitPositionGoal
    );
    _mobOrbit.goalSelector.addGoal(1, new ${package}.ai.OrbitPositionGoal(_mobOrbit, _cx, _cy, _cz, _speed, _radius, _tiltAngle, _dynamicRotSpeed, _stopCondition));
}