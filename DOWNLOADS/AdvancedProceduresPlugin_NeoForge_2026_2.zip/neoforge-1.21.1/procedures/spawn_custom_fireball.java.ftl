<#include "mcitems.ftl">

<#assign shooterEntity = input$shooter!"entity">

if (${shooterEntity} instanceof net.minecraft.world.entity.LivingEntity _shooter) {
    net.minecraft.world.level.Level _world = _shooter.level();
    if (!_world.isClientSide()) {
        net.minecraft.world.phys.Vec3 _look = _shooter.getViewVector(1.0f);
        double _speed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>1.0</#if>;
        double _inaccuracy = <#if input$inaccuracy?? && input$inaccuracy?has_content>${input$inaccuracy}<#else>0.0</#if>;

        net.minecraft.util.RandomSource _rnd = _world.getRandom();
        net.minecraft.world.phys.Vec3 _dir = _look.normalize()
            .add(_rnd.triangle(0.0D, 0.0172275D * _inaccuracy),
                 _rnd.triangle(0.0D, 0.0172275D * _inaccuracy),
                 _rnd.triangle(0.0D, 0.0172275D * _inaccuracy))
            .normalize();

        net.minecraft.world.phys.Vec3 _accel = _dir.scale(_speed * 0.1D);

        ${package}.entity.CustomFireballEntity _fireball = new ${package}.entity.CustomFireballEntity(
            ${package}.entity.CustomFireballEntity.TYPE, 
            _shooter, 
            _accel,
            _world
        );

        <#if input$texture?? && input$texture?has_content>
            <#assign texInput = input$texture>
            <#if texInput?contains("ItemStack") || texInput?contains("getUseItem") || texInput?contains("getMainHandItem")>
                _fireball.setCustomTexture(${texInput});
            <#else>
                _fireball.setCustomTexture(new net.minecraft.world.item.ItemStack(${texInput}));
            </#if>
        <#else>
            _fireball.setCustomTexture(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.FIRE_CHARGE));
        </#if>
        double _sizeInput = <#if input$size?? && input$size?has_content>${input$size}<#else>1.0</#if>;
        _fireball.setCustomSize((float) Math.max(0.5D, Math.min(15.0D, _sizeInput)));

        boolean _useGravity = <#if input$useGravity?? && input$useGravity?has_content>${input$useGravity}<#else>false</#if>;
        _fireball.setGravityEnabled(_useGravity);

        <#if field$trailParticle?? && field$trailParticle?has_content>
            <#assign particleVal = field$trailParticle>
            <#if particleVal?starts_with("net.minecraft")>
                _fireball.setTrailParticle(${particleVal});
            <#else>
                _fireball.setTrailParticle(net.minecraft.core.particles.ParticleTypes.${particleVal?upper_case});
            </#if>
        </#if>

        boolean _enableFire = <#if input$enableFire?? && input$enableFire?has_content>${input$enableFire}<#else>true</#if>;

        <#assign expRadius = 0.0>
        <#if field$destroyMode??>
            <#if field$destroyMode == "0">
                <#assign expRadius = 0.0>
            <#elseif field$destroyMode == "1">
                <#assign expRadius = 2.0>
            <#elseif field$destroyMode == "2">
                <#assign expRadius = 4.0>
            <#elseif field$destroyMode == "3">
                <#assign expRadius = 8.0>
            </#if>
        </#if>

        <#assign fireRad = 0>
        <#if field$fireMode??>
            <#if field$fireMode == "1">
                <#assign fireRad = 1>
            <#elseif field$fireMode == "2">
                <#assign fireRad = 3>
            <#elseif field$fireMode == "3">
                <#assign fireRad = 5>
            <#elseif field$fireMode == "4">
                <#assign fireRad = 8>
            </#if>
        </#if>

        _fireball.setExplosionParams(${expRadius}f, ${fireRad}, _enableFire);

        _fireball.setPos(_shooter.getX() + _dir.x * 1.2, _shooter.getEyeY() + _dir.y * 1.2, _shooter.getZ() + _dir.z * 1.2);
        
        _world.addFreshEntity(_fireball);
    }
}