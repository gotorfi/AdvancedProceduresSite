<#include "mcitems.ftl">

if (world instanceof net.minecraft.server.level.ServerLevel _level) {
    net.minecraft.core.BlockPos _spawnPos = net.minecraft.core.BlockPos.containing((double) x, (double) y, (double) z);

    <#if input$structure?? && input$structure?has_content>
        String _structInput = ${input$structure};
    <#else>
        <#assign structInput = field$structure!"minecraft:eye_of_ender_located">
        String _structInput = "${structInput}";
    </#if>

    if (!_structInput.contains(":") && !_structInput.startsWith("#")) {
        _structInput = "${modid}:" + _structInput;
    }

    net.minecraft.core.HolderSet<net.minecraft.world.level.levelgen.structure.Structure> _structHolderSet = null;
    var _registry = _level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.STRUCTURE);

    if (_structInput.startsWith("#")) {
        net.minecraft.resources.ResourceLocation _tagLoc = net.minecraft.resources.ResourceLocation.parse(_structInput.substring(1));
        net.minecraft.tags.TagKey<net.minecraft.world.level.levelgen.structure.Structure> _structTag = 
            net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.STRUCTURE, _tagLoc);

        _structHolderSet = _registry.get(_structTag).orElse(null);
    } else {
        net.minecraft.resources.ResourceLocation _structLoc = net.minecraft.resources.ResourceLocation.parse(_structInput);
        net.minecraft.resources.ResourceKey<net.minecraft.world.level.levelgen.structure.Structure> _structKey = 
            net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.STRUCTURE, _structLoc);

        var _holderOpt = _registry.get(_structKey);
        if (_holderOpt.isPresent()) {
            _structHolderSet = net.minecraft.core.HolderSet.direct(_holderOpt.get());
        }
    }

    if (_structHolderSet != null) {
        var _foundStruct = _level.getChunkSource().getGenerator().findNearestMapStructure(_level, _structHolderSet, _spawnPos, 100, false);

        if (_foundStruct != null && _foundStruct.getFirst() != null) {
            net.minecraft.core.BlockPos _targetPos = _foundStruct.getFirst();

            ${package}.entity.CustomEyeOfEnderEntity _eye = 
                new ${package}.entity.CustomEyeOfEnderEntity(_level, (double) x, (double) y + 1.2D, (double) z);


            <#if input$texture?? && input$texture?has_content>
                <#assign texInput = input$texture>
                <#if texInput?contains("ItemStack") || texInput?contains("getUseItem") || texInput?contains("getMainHandItem")>
                    _eye.setItem(${texInput});
                <#else>
                    _eye.setItem(new net.minecraft.world.item.ItemStack(${texInput}));
                </#if>
            <#else>
                _eye.setItem(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.ENDER_EYE));
            </#if>

            <#if field$ambientParticle?? && field$ambientParticle?has_content>
                <#assign ambParticleVal = field$ambientParticle>
                <#if ambParticleVal?starts_with("net.minecraft")>
                    _eye.setAmbientParticle(${ambParticleVal});
                <#else>
                    _eye.setAmbientParticle(net.minecraft.core.particles.ParticleTypes.${ambParticleVal?upper_case});
                </#if>
            </#if>

            <#if field$breakParticle?? && field$breakParticle?has_content>
                <#assign brkParticleVal = field$breakParticle>
                <#if brkParticleVal?starts_with("net.minecraft")>
                    _eye.setBreakParticle(${brkParticleVal});
                <#else>
                    _eye.setBreakParticle(net.minecraft.core.particles.ParticleTypes.${brkParticleVal?upper_case});
                </#if>
            </#if>

            double _chance = <#if input$breakChance?? && input$breakChance?has_content>${input$breakChance}<#else>0.2D</#if>;
            _eye.setBreakChance(_chance);

            _eye.signalToPos(_targetPos);
            _level.addFreshEntity(_eye);
        }
    }
}