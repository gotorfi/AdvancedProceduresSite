<#include "mcitems.ftl">
(world instanceof net.minecraft.world.level.Level _level ? net.minecraft.core.BlockPos.betweenClosedStream(
    net.minecraft.core.BlockPos.containing((double) ${input$x}, (double) ${input$y}, (double) ${input$z}).offset(
        -(int)${input$radius}, -(int)${input$radius}, -(int)${input$radius}
    ),
    net.minecraft.core.BlockPos.containing((double) ${input$x}, (double) ${input$y}, (double) ${input$z}).offset(
        (int)${input$radius}, (int)${input$radius}, (int)${input$radius}
    )
).anyMatch(_pos -> {
    net.minecraft.world.item.Item _item = ${mappedMCItemToItem(input$block)};
    if (_item instanceof net.minecraft.world.item.BlockItem _bi) {
        return _level.getBlockState(_pos).is(_bi.getBlock());
    }
    return false;
}) : false)