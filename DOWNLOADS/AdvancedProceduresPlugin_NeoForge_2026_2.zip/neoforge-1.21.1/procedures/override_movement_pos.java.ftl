<#include "mcitems.ftl">
if (${input$entity} != null) {
    double _x = ${input$x};
    double _y = ${input$y};
    double _z = ${input$z};
    double _speed = <#if input$speed?? && input$speed?has_content>${input$speed}<#else>1.0D</#if>;
    boolean _canFly = <#if input$canFly?? && input$canFly?has_content>${input$canFly}<#else>false</#if>;
    String _easing = "${field$easing!"LINEAR"}";

    if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
        _mob.getPersistentData().putBoolean("abandonBlockTask", false);

        _mob.goalSelector.getAvailableGoals().removeIf(wrappedGoal -> 
            wrappedGoal.getGoal() instanceof ${package}.ai.OverrideMovementGoal
        );
        _mob.goalSelector.addGoal(0, new ${package}.ai.OverrideMovementGoal(_mob, _x, _y, _z, _speed, _canFly, _easing));
    } else if (${input$entity} instanceof net.minecraft.world.entity.player.Player _player) {
        net.minecraft.world.phys.Vec3 _targetVec = new net.minecraft.world.phys.Vec3(_x, _y, _z);
        net.minecraft.world.phys.Vec3 _dir = _targetVec.subtract(_player.position()).normalize();
        _player.setDeltaMovement(_dir.scale(_speed * 0.3D));
        _player.hurtMarked = true;
    }
}