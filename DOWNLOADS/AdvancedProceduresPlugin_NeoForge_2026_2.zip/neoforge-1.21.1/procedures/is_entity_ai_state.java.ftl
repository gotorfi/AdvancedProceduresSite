(${input$entity} != null ? (
    "${field$mode}".equals("HasImmunity") ? ${input$entity}.isInvulnerable() :
    (${input$entity} instanceof net.minecraft.world.entity.Mob _mob ? (
        "${field$mode}".equals("IsFrozen") ? _mob.isNoAi() : 
        "${field$mode}".equals("Brainless") ? _mob.goalSelector.getAvailableGoals().isEmpty() : 
        false
    ) : false)
) : false)