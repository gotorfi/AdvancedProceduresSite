<#include "mcitems.ftl">
if (world instanceof net.minecraft.server.level.ServerLevel _level) {
	Object _rawX = (double) x;
	Object _rawY = (double) y;
	Object _rawZ = (double) z;

	double _cx = net.minecraft.util.Mth.floor(_rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX)));
	double _cy = net.minecraft.util.Mth.floor(_rawY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY)));
	double _cz = net.minecraft.util.Mth.floor(_rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ)));

	int _r = (int) ${input$radius};
	double _p = ${input$power};
	boolean _grav = ${input$gravity};
	net.minecraft.core.BlockPos _center = net.minecraft.core.BlockPos.containing(_cx, _cy, _cz);
	for (int _dx = -_r; _dx <= _r; _dx++) {
		for (int _dy = -_r; _dy <= _r; _dy++) {
			for (int _dz = -_r; _dz <= _r; _dz++) {
				if (_dx * _dx + _dy * _dy + _dz * _dz <= _r * _r) {
					net.minecraft.core.BlockPos _pos = _center.offset(_dx, _dy, _dz);
					net.minecraft.world.level.block.state.BlockState _state = _level.getBlockState(_pos);
					if (!_state.isAir() && _state.getDestroySpeed(_level, _pos) >= 0) {
						<#assign hasValidIgnores = false>

						<#if field$IGNORE_DATA?? && field$IGNORE_DATA?has_content && field$IGNORE_DATA != "[]">
							<#assign ignores = field$IGNORE_DATA?eval />
							<#list ignores as item>
								<#if item.blockName?? && item.blockName?has_content>
									<#assign hasValidIgnores = true>
								</#if>
							</#list>
						</#if>

						<#if hasValidIgnores>
						boolean _shouldIgnore = false;
						<#list ignores as item>
							<#if item.blockName?? && item.blockName?has_content>
							{
								<#assign rawBlock = item.blockName>
								<#assign javaBlockCode = "">

								<#if rawBlock == "Blocks.STONE#1">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.GRANITE">
								<#elseif rawBlock == "Blocks.STONE#2">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.POLISHED_GRANITE">
								<#elseif rawBlock == "Blocks.STONE#3">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.DIORITE">
								<#elseif rawBlock == "Blocks.STONE#4">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.POLISHED_DIORITE">
								<#elseif rawBlock == "Blocks.STONE#5">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.ANDESITE">
								<#elseif rawBlock == "Blocks.STONE#6">
									<#assign javaBlockCode = "net.minecraft.world.level.block.Blocks.POLISHED_ANDESITE">
								<#else>
									<#assign cleanBlock = rawBlock?keep_before("#")>
									<#assign javaBlockCode = mappedBlockToBlock(cleanBlock)>
								</#if>

								if (_state.is(${javaBlockCode})) {
									_shouldIgnore = true;
								}
							}
							</#if>
						</#list>
						if (!_shouldIgnore) {
						</#if>
						double _vx = _pos.getX() + 0.5d - _cx;
						double _vy = _pos.getY() + 0.5d - _cy;
						double _vz = _pos.getZ() + 0.5d - _cz;
						double _dist = Math.sqrt(_vx * _vx + _vy * _vy + _vz * _vz);
						if (_dist > 0) {
							_vx = (_vx / _dist) * _p;
							_vy = (_vy / _dist) * _p + 0.2d;
							_vz = (_vz / _dist) * _p;
						}
						net.minecraft.world.entity.item.FallingBlockEntity _falling = net.minecraft.world.entity.item.FallingBlockEntity.fall(_level, _pos, _state);
						if (_falling != null) {
							_level.setBlock(_pos, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
							_falling.setDeltaMovement(new net.minecraft.world.phys.Vec3(_vx, _vy, _vz));
							_falling.hurtMarked = true;
							if (!_grav) {
								_falling.setNoGravity(true);
								final net.minecraft.core.BlockPos _startPos = _pos;
								final net.minecraft.world.entity.item.FallingBlockEntity _fEntity = _falling;
								_level.getServer().submit(() -> {
									if (_fEntity.isAlive() && _fEntity.distanceToSqr(_startPos.getX(), _startPos.getY(), _startPos.getZ()) > 4096) {
										_fEntity.discard();
									}
								});
							}
						}
						<#if hasValidIgnores>
						}
						</#if>
					}
				}
			}
		}
	}
}