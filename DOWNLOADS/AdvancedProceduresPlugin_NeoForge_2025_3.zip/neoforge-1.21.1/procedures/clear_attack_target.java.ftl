if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobClearTask) {
    net.minecraft.nbt.CompoundTag _pd = _mobClearTask.getPersistentData();
    _pd.remove("blockLock");
    _pd.remove("targetBlockX");
    _pd.remove("targetBlockY");
    _pd.remove("targetBlockZ");
    _pd.remove("abandonBlockTask");

    _mobClearTask.goalSelector.getAvailableGoals().removeIf(wrappedGoal -> 
        wrappedGoal.getGoal() instanceof ${package}.ai.MoveToStructureGoal
    );

    _mobClearTask.setTarget(null);
    _mobClearTask.getNavigation().stop();
}