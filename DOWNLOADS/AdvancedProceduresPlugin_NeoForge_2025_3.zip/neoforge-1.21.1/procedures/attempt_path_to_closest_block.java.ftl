<#include "mcitems.ftl">
if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    <#assign mode = field$MODE!"PRIORITY_LOCK">
    net.minecraft.world.item.Item _targetItem = ${mappedMCItemToItem(input$block)};
    if (_targetItem instanceof net.minecraft.world.item.BlockItem _blockItem) {
        net.minecraft.world.level.block.Block _targetBlock = _blockItem.getBlock();
        net.minecraft.nbt.CompoundTag _pd = _mob.getPersistentData();

        <#if mode == "RESET_ON_HIT">
        if (_mob.getTarget() != null && _mob.getTarget().isAlive()) {
            _pd.putBoolean("abandonBlockTask", true);
        }

        if (_pd.getBoolean("abandonBlockTask")) {
            _pd.remove("targetBlockX");
            _pd.remove("targetBlockY");
            _pd.remove("targetBlockZ");
            _pd.remove("blockLock");
            return;
        }
        </#if>

        net.minecraft.core.BlockPos _targetPos = null;

        if (_pd.contains("targetBlockX")) {
            int _tx = _pd.getInt("targetBlockX");
            int _ty = _pd.getInt("targetBlockY");
            int _tz = _pd.getInt("targetBlockZ");
            net.minecraft.core.BlockPos _cachedPos = new net.minecraft.core.BlockPos(_tx, _ty, _tz);

            if (_mob.level().getBlockState(_cachedPos).is(_targetBlock)) {
                _targetPos = _cachedPos;
            } else {
                _pd.remove("targetBlockX");
                _pd.remove("targetBlockY");
                _pd.remove("targetBlockZ");
            }
        }

        if (_mob.tickCount % 10 == 0) {
            net.minecraft.core.BlockPos _center = _mob.blockPosition();
            net.minecraft.core.BlockPos _found = null;
            double _closestDistSq = Double.MAX_VALUE;

            for (net.minecraft.core.BlockPos _p : net.minecraft.core.BlockPos.betweenClosed(_center.offset(-15, -6, -15), _center.offset(15, 6, 15))) {
                if (_mob.level().getBlockState(_p).is(_targetBlock)) {
                    double _dist = _p.distSqr(_center);
                    if (_dist < _closestDistSq) {
                        _closestDistSq = _dist;
                        _found = _p.immutable();
                    }
                }
            }

            if (_found != null) {
                if (_targetPos == null || _center.distSqr(_found) < _center.distSqr(_targetPos)) {
                    _targetPos = _found;
                    _pd.putInt("targetBlockX", _targetPos.getX());
                    _pd.putInt("targetBlockY", _targetPos.getY());
                    _pd.putInt("targetBlockZ", _targetPos.getZ());
                }
            }
        }

        if (_targetPos != null) {
            _pd.putBoolean("blockLock", true);

            <#if mode == "PRIORITY_LOCK" || mode == "STAND_WAIT">
            _mob.setTarget(null);
            </#if>

            _mob.getLookControl().setLookAt(
                (double) _targetPos.getX() + 0.5D, 
                (double) _targetPos.getY() + 0.5D, 
                (double) _targetPos.getZ() + 0.5D, 
                180.0F, 180.0F
            );

            double _dx = ((double) _targetPos.getX() + 0.5D) - _mob.getX();
            double _dz = ((double) _targetPos.getZ() + 0.5D) - _mob.getZ();
            float _yaw = (float) (Math.atan2(_dz, _dx) * (180.0D / Math.PI)) - 90.0F;
            _mob.setYRot(_yaw);
            _mob.setYHeadRot(_yaw);
            _mob.setYBodyRot(_yaw);
            _mob.yRotO = _yaw;

            if (_mob.blockPosition().distSqr(_targetPos) <= 1) {
                _mob.getNavigation().stop();

                <#if mode == "ONCE">
                _pd.remove("targetBlockX");
                _pd.remove("targetBlockY");
                _pd.remove("targetBlockZ");
                _pd.remove("blockLock");
                </#if>
            } else {
                if (_mob.getNavigation().isDone() || _mob.tickCount % 5 == 0) {
                    _mob.getNavigation().moveTo(
                        (double) _targetPos.getX() + 0.5D, 
                        (double) _targetPos.getY(), 
                        (double) _targetPos.getZ() + 0.5D, 
                        1.2d
                    );
                }
            }
        } else {
            _pd.remove("blockLock");

            <#if mode == "STAND_WAIT">
            _mob.getNavigation().stop();
            _mob.setTarget(null);
            </#if>
        }
    }
}