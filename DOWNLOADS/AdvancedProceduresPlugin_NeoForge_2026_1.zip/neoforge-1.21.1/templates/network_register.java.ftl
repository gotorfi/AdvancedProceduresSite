package ${package}.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class NetworkRegister {

    public static void registerPayloads(final RegisterPayloadHandlersEvent event) {
        final PayloadRegistrar registrar = event.registrar("1");
        
        registrar.playToClient(
            CameraShakePayload.TYPE,
            CameraShakePayload.STREAM_CODEC,
            CameraShakePayload::handleData
        );
    }
}