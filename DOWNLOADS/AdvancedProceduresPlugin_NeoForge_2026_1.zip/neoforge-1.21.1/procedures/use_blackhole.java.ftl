double _x${cbi} = (double) ${input$x};
double _y${cbi} = (double) ${input$y};
double _z${cbi} = (double) ${input$z};

int _stack${cbi} = (int) <#if input$blockStack?? && input$blockStack?has_content>${input$blockStack}<#else>1</#if>;
double _blockRad${cbi} = (double) <#if input$blockRadius?? && input$blockRadius?has_content>${input$blockRadius}<#else>10.0</#if>;
boolean _pullEnt${cbi} = <#if input$pullEntities?? && input$pullEntities?has_content>${input$pullEntities}<#else>true</#if>;
double _entRad${cbi} = (double) <#if input$entityRadius?? && input$entityRadius?has_content>${input$entityRadius}<#else>15.0</#if>;
double _power${cbi} = (double) <#if input$power?? && input$power?has_content>${input$power}<#else>1.0</#if>;
boolean _killEnt${cbi} = <#if input$killEntities?? && input$killEntities?has_content>${input$killEntities}<#else>true</#if>;
boolean _active${cbi} = <#if input$active?? && input$active?has_content>${input$active}<#else>true</#if>;

${package}.world.BlackHoleManager.setBlackHole(
    world, _x${cbi}, _y${cbi}, _z${cbi}, 
    _stack${cbi}, _blockRad${cbi}, _pullEnt${cbi}, 
    _entRad${cbi}, _power${cbi}, _killEnt${cbi}, _active${cbi}
);