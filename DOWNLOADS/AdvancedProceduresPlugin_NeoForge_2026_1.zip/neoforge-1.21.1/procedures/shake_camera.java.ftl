<#-- @formatter:off -->
<#assign target_val = field$target!"Player">
<#assign power_val = input$power!"1.0">
<#assign duration_val = input$duration!"2.0">

if (world instanceof net.minecraft.server.level.ServerLevel _serverLevel) {
    float _power = (float) ${power_val};
    int _durationTicks = (int) (${duration_val} * 20.0);
    net.minecraft.network.protocol.common.custom.CustomPacketPayload _payload = new ${package}.network.CameraShakePayload(_power, _durationTicks);

    <#if target_val == "Player">
    if (${input$entity!"entity"} instanceof net.minecraft.server.level.ServerPlayer _serverPlayer) {
        net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(_serverPlayer, _payload);
    }
    <#elseif target_val == "AllPlayers">
    for (net.minecraft.server.level.ServerPlayer _serverPlayer : _serverLevel.players()) {
        net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(_serverPlayer, _payload);
    }
    <#elseif target_val == "RandomPlayers">
    java.util.List<net.minecraft.server.level.ServerPlayer> _allPlayers = new java.util.ArrayList<>(_serverLevel.players());
    if (!_allPlayers.isEmpty()) {
        java.util.Collections.shuffle(_allPlayers);
        int _count = Math.max(1, _serverLevel.random.nextInt(_allPlayers.size()) + 1);
        for (int _i = 0; _i < _count; _i++) {
            net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(_allPlayers.get(_i), _payload);
        }
    }
    </#if>
} else if (world instanceof net.minecraft.world.level.LevelAccessor _levelAccessor && _levelAccessor.isClientSide()) {
    ${package}.client.CameraShakeManager.getInstance().shake((float) ${power_val}, (int) (${duration_val} * 20.0));
}
<#-- @formatter:on -->