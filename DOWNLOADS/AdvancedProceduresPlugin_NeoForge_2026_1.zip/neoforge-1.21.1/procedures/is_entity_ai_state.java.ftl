(${input$entity} != null ? (
    "${field$mode}".equals("HasImmunity") ? ${input$entity}.isInvulnerable() :
    ("${field$mode}".equals("Climbing") ? (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _climbEnt && _climbEnt.onClimbable()) :
    ("${field$mode}".equals("SwingingMainHand") ? (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _swingMainEnt && _swingMainEnt.swinging && _swingMainEnt.swingingArm == net.minecraft.world.InteractionHand.MAIN_HAND) :
    ("${field$mode}".equals("SwingingOffHand") ? (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _swingOffEnt && _swingOffEnt.swinging && _swingOffEnt.swingingArm == net.minecraft.world.InteractionHand.OFF_HAND) :
    (${input$entity} instanceof net.minecraft.world.entity.Mob _mob ? (
        "${field$mode}".equals("IsFrozen") ? _mob.isNoAi() : 
        "${field$mode}".equals("Brainless") ? _mob.goalSelector.getAvailableGoals().isEmpty() : 
        "${field$mode}".equals("HasVanillaTask") ? (!_mob.isNoAi() && (_mob.getTarget() != null || !_mob.getNavigation().isDone())) :
        "${field$mode}".equals("HasCustomTask") ? (
            _mob.getPersistentData().contains("blockLock") ||
            _mob.getPersistentData().contains("targetBlockX") ||
            _mob.getPersistentData().contains("targetBlockY") ||
            _mob.getPersistentData().contains("targetBlockZ") ||
            _mob.getPersistentData().contains("orbitCenterX") ||
            _mob.getPersistentData().contains("orbitCenterY") ||
            _mob.getPersistentData().contains("orbitCenterZ") ||
            _mob.getPersistentData().getBoolean("abandonBlockTask") ||
            _mob.goalSelector.getAvailableGoals().stream().anyMatch(_g -> 
                _g.getGoal() instanceof ${package}.ai.MoveToBlockGoal ||
                _g.getGoal() instanceof ${package}.ai.MoveToStructureGoal ||
                _g.getGoal() instanceof ${package}.ai.OverrideMovementGoal ||
                _g.getGoal() instanceof ${package}.ai.OrbitPositionGoal
            )
        ) :
        false
    ) : false))))
) : false)