<#-- @formatter:off -->
<#assign time_val = input$time!"20">
<#assign code_str = statement$do!"">
<#assign block_id = "cd_" + code_str?length + "_" + code_str?html?length>
<#assign unit_val = field$unit!"Seconds">
<#assign side_val = field$side!"Server">

<#if unit_val == "Seconds">
    <#assign ticks_val = "(long) (" + time_val + " * 20)">
<#else>
    <#assign ticks_val = "(long) " + time_val>
</#if>

<#if side_val == "Client">
    <#assign side_check = "_lvl.isClientSide()">
<#else>
    <#assign side_check = "!_lvl.isClientSide()">
</#if>

<#if entity??>
if (${entity}.level() instanceof net.minecraft.world.level.Level _lvl && ${side_check}) {
    String _cdKey = "${block_id}_" + ${entity}.getUUID().toString();
    if (${package}.math.CallCooldownManager.shouldExecute(_cdKey, ${ticks_val}, _lvl.getGameTime())) {
        ${statement$do!}
    }
}
<#elseif world??>
if (${world} instanceof net.minecraft.world.level.Level _lvl && ${side_check}) {
    String _cdKey = "${block_id}_global";
    if (${package}.math.CallCooldownManager.shouldExecute(_cdKey, ${ticks_val}, _lvl.getGameTime())) {
        ${statement$do!}
    }
}
<#else>
if (net.neoforged.neoforge.server.ServerLifecycleHooks.getCurrentServer() != null) {
    net.minecraft.world.level.Level _lvl = net.neoforged.neoforge.server.ServerLifecycleHooks.getCurrentServer().overworld();
    if (${side_check}) {
        String _cdKey = "${block_id}_global";
        if (${package}.math.CallCooldownManager.shouldExecute(_cdKey, ${ticks_val}, _lvl.getGameTime())) {
            ${statement$do!}
        }
    }
}
</#if>
<#-- @formatter:on -->