package ${package}.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import ${package}.entity.CustomFireballEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.ThrownItemRenderState;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(value = Dist.CLIENT)
public class CustomFireballRenderer extends EntityRenderer<CustomFireballEntity, CustomFireballRenderer.FireballRenderState> {

    @SubscribeEvent
    public static void registerRenderer(EntityRenderersEvent.RegisterRenderers event) {
        if (CustomFireballEntity.TYPE != null) {
            event.registerEntityRenderer(CustomFireballEntity.TYPE, CustomFireballRenderer::new);
        }
    }

    private final ItemModelResolver itemModelResolver;

    public CustomFireballRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemModelResolver = context.getItemModelResolver();
    }

    @Override
    public FireballRenderState createRenderState() {
        return new FireballRenderState();
    }

    @Override
    public void extractRenderState(CustomFireballEntity entity, FireballRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.size = entity.getCustomSize();
        ItemStack stack = entity.getItem();
        ItemStack itemToRender = stack.isEmpty() ? new ItemStack(Items.FIRE_CHARGE) : stack;
        this.itemModelResolver.updateForNonLiving(state.item, itemToRender, ItemDisplayContext.GROUND, entity);
    }

    @Override
    protected int getBlockLightLevel(CustomFireballEntity entity, BlockPos blockPos) {
        return 15;
    }

    @Override
    public void render(FireballRenderState state, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        float scale = state.size;
        poseStack.scale(scale, scale, scale);

        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));

        state.item.render(
            poseStack,
            buffer,
            packedLight,
            0
        );

        poseStack.popPose();
        super.render(state, poseStack, buffer, packedLight);
    }

    public static class FireballRenderState extends ThrownItemRenderState {
        public float size = 1.0F;
    }
}