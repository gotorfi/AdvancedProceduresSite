package ${package}.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import ${package}.entity.CustomEyeOfEnderEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.ThrownItemRenderState;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(value = Dist.CLIENT)
public class CustomEyeOfEnderRenderer extends EntityRenderer<CustomEyeOfEnderEntity, CustomEyeOfEnderRenderer.EyeRenderState> {

    @SubscribeEvent
    public static void registerRenderer(EntityRenderersEvent.RegisterRenderers event) {
        if (CustomEyeOfEnderEntity.TYPE != null) {
            event.registerEntityRenderer(CustomEyeOfEnderEntity.TYPE, CustomEyeOfEnderRenderer::new);
        }
    }

    private final ItemModelResolver itemModelResolver;

    public CustomEyeOfEnderRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemModelResolver = context.getItemModelResolver();
    }

    @Override
    public EyeRenderState createRenderState() {
        return new EyeRenderState();
    }

    @Override
    public void extractRenderState(CustomEyeOfEnderEntity entity, EyeRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        ItemStack stack = entity.getItem();
        ItemStack itemToRender = stack.isEmpty() ? new ItemStack(Items.ENDER_EYE) : stack;
        this.itemModelResolver.updateForNonLiving(state.item, itemToRender, ItemDisplayContext.GROUND, entity);
    }

    @Override
    protected int getBlockLightLevel(CustomEyeOfEnderEntity entity, BlockPos blockPos) {
        return 15;
    }

    @Override
    public void render(EyeRenderState state, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        poseStack.scale(2.0F, 2.0F, 2.0F);

        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
        state.item.render(
            poseStack,
            buffer,
            packedLight,
            0
        );

        poseStack.popPose();
        super.render(state, poseStack, buffer, packedLight);
    }

    public static class EyeRenderState extends ThrownItemRenderState {
    }
}