<#include "mcelements.ftl">
<#include "mcitems.ftl">
<#assign sound = generator.map(field$sound!"portal", "sounds")?replace("CUSTOM:", "${modid}:")?lower_case>
<#assign particleRaw = generator.map(field$particle!"portal", "particles")>
<#assign particle = particleRaw?replace("ParticleTypes.", "")?replace("CUSTOM:", "${modid}:")?lower_case>

if (world instanceof net.minecraft.server.level.ServerLevel _level) {
	net.minecraft.core.BlockPos _pos = ${toBlockPos(input$x, input$y, input$z)};
	if (${input$enabled}) {
		net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> _targetDim = ${generator.map(field$dimension, "dimensions")};
		
		net.minecraft.resources.ResourceLocation _soundId = net.minecraft.resources.ResourceLocation.parse("${sound}");
		net.minecraft.sounds.SoundEvent _soundEvt = net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(_soundId).map(net.minecraft.core.Holder::value).orElse(null);
		
		net.minecraft.resources.ResourceLocation _partId = net.minecraft.resources.ResourceLocation.parse("${particle}");
		net.minecraft.core.particles.ParticleType<?> _partType = net.minecraft.core.registries.BuiltInRegistries.PARTICLE_TYPE.get(_partId).map(net.minecraft.core.Holder::value).orElse(null);
		net.minecraft.core.particles.ParticleOptions _partOpt = _partType instanceof net.minecraft.core.particles.ParticleOptions _opt ? _opt : null;
		
		int _ticks = (int) (${opt.toDouble(input$seconds)} * 20);
		int _offsetY = (int) ${opt.toDouble(input$trigger_offset_y)};

		${package}.world.TeleportBlockHandler.registerPortal(
			_level, 
			_level.dimension(), 
			_pos, 
			_targetDim, 
			${opt.toDouble(input$target_x)}, 
			${opt.toDouble(input$target_y)}, 
			${opt.toDouble(input$target_z)}, 
			_soundEvt, 
			_partOpt, 
			_ticks, 
			_offsetY
		);
	} else {
		${package}.world.TeleportBlockHandler.unregisterPortal(
			_level,
			_level.dimension(),
			_pos
		);
	}
}