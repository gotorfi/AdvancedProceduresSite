Blockly.Extensions.register("get_output_type",
    function () {
        const block = this;
        block.getField("output_type").setVisible(false);
        block.setOnChange(
            function (changeEvent) {
                if (!block.workspace || block.isInFlyout) {
                    return;
                }
                if ((changeEvent.type !== Blockly.Events.BLOCK_CHANGE || changeEvent.element !== 'field') &&
                    changeEvent.type !== Blockly.Events.BLOCK_MOVE) {
                    return;
                }
                const input = block.getInput("value");
                if (!input || !input.connection) {
                    return;
                }
                const target = input.connection.targetBlock();
                let type = "null";
                if (target && target.outputConnection) {
                    const check = target.outputConnection.check_;
                    if (Array.isArray(check)) {
                        type = check[0];
                    } else if (typeof check === "string") {
                        type = check;
                    } else {
                        type = "Any";
                    }
                }
                block.getField("output_type").setValue(type);
            }
        );
    }
);

registerSimpleMutatorContainer('enchantment_list_container', 'enchantments', '#8a0f42');
registerSimpleMutatorInput('enchantment_list_item', 'enchantment', '#8a0f42', true);

Blockly.Extensions.register('enchantment_list_init', function () {
    this.enchantCount_ = 0;
    if (!this.getField('ENCHANT_DATA')) {
        const input = this.appendDummyInput('DUMMY_ENCHANT_DATA');
        const field = new Blockly.FieldTextInput('[]');
        input.appendField(field, 'ENCHANT_DATA');
        input.setVisible(false);
        field.setVisible(false);
    }
});

Blockly.Extensions.registerMutator('enchantment_list_mutator', {
    saveEnchantData_: function () {
        const enchantData = [];
        for (let i = 0; i < (this.enchantCount_ || 0); i++) {
            const ench = this.getFieldValue('ENCH' + i) || '';
            const lvl = parseInt(this.getFieldValue('LVL' + i) || '1', 10);
            const rand = this.getFieldValue('RAND' + i) === 'TRUE' || this.getFieldValue('RAND' + i) === true;
            enchantData.push({ ench: ench, lvl: lvl, rand: rand });
        }
        if (this.getField('ENCHANT_DATA')) {
            this.setFieldValue(JSON.stringify(enchantData), 'ENCHANT_DATA');
        }
    },

    mutationToDom: function () {
        this.saveEnchantData_();
        const container = document.createElement('mutation');
        container.setAttribute('enchants', this.enchantCount_ || 0);
        return container;
    },

    domToMutation: function (xmlElement) {
        this.enchantCount_ = isNaN(xmlElement.getAttribute('enchants')) ?
            0 : parseInt(xmlElement.getAttribute('enchants'), 10);
        this.updateShape_();
    },

    saveExtraState: function () {
        this.saveEnchantData_();
        return { 'enchantCount': this.enchantCount_ || 0 };
    },

    loadExtraState: function (state) {
        this.enchantCount_ = state ? (state['enchantCount'] || 0) : 0;
        this.updateShape_();
    },

    decompose: function (workspace) {
        const containerBlock = workspace.newBlock('enchantment_list_container');
        containerBlock.initSvg();
        let connection = containerBlock.getInput('STACK').connection;
        for (let i = 0; i < this.enchantCount_; i++) {
            const itemBlock = workspace.newBlock('enchantment_list_item');
            itemBlock.initSvg();
            connection.connect(itemBlock.previousConnection);
            connection = itemBlock.nextConnection;
        }
        return containerBlock;
    },

    compose: function (containerBlock) {
        let itemBlock = containerBlock.getInputTargetBlock('STACK');
        const connections = [];
        while (itemBlock && !itemBlock.isInsertionMarker()) {
            connections.push(itemBlock.valueConnection_);
            itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
        }
        this.enchantCount_ = connections.length;
        this.updateShape_();
        this.saveEnchantData_();
    },

    saveConnections: function (containerBlock) {
        // skip
    },

    updateShape_: function () {
        if (!this.getField('ENCHANT_DATA')) {
            const dummyInput = this.appendDummyInput('DUMMY_ENCHANT_DATA');
            const hiddenField = new Blockly.FieldTextInput('[]');
            dummyInput.appendField(hiddenField, 'ENCHANT_DATA');
            dummyInput.setVisible(false);
            hiddenField.setVisible(false);
        }

        for (let i = 0; i < this.enchantCount_; i++) {
            if (!this.getInput('ENCH_ROW' + i)) {
                this.appendDummyInput('ENCH_ROW' + i)
                    .setAlign(Blockly.Input.Align.RIGHT)
                    .appendField("With enchantment")
                    .appendField(new FieldDataListSelector("enchantments", undefined, {
                        'customEntryProviders': 'enchantment'
                    }), 'ENCH' + i)
                    .appendField("With level")
                    .appendField(new Blockly.FieldNumber(1, 1, 255), 'LVL' + i)
                    .appendField(", Random amount:")
                    .appendField(new Blockly.FieldCheckbox(false), 'RAND' + i);
            }
        }
        for (let i = this.enchantCount_; this.getInput('ENCH_ROW' + i); i++) {
            this.removeInput('ENCH_ROW' + i);
        }
    }
}, undefined, ['enchantment_list_item']);


registerSimpleMutatorContainer('title_text_container', 'title_text', '#4a57a8');
registerSimpleMutatorInput('title_text_item', 'text_part', '#4a57a8', true);

Blockly.Extensions.register('title_text_init', function () {
    this.itemCount_ = 1;
    if (!this.getField('TEXT_DATA')) {
        const input = this.appendDummyInput('DUMMY_TEXT_DATA');
        const field = new Blockly.FieldTextInput('[]');
        input.appendField(field, 'TEXT_DATA');
        input.setVisible(false);
        field.setVisible(false);
    }
    this.updateShape_();
});

Blockly.Extensions.registerMutator('title_text_mutator', {
    saveTextData_: function () {
        const textData = [];
        for (let i = 0; i < (this.itemCount_ || 0); i++) {
            textData.push({ index: i });
        }
        if (this.getField('TEXT_DATA')) {
            this.setFieldValue(JSON.stringify(textData), 'TEXT_DATA');
        }
    },

    mutationToDom: function () {
        this.saveTextData_();
        const container = document.createElement('mutation');
        container.setAttribute('items', this.itemCount_ || 1);
        return container;
    },

    domToMutation: function (xmlElement) {
        this.itemCount_ = parseInt(xmlElement.getAttribute('items'), 10) || 1;
        this.updateShape_();
    },

    saveExtraState: function () {
        this.saveTextData_();
        return { 'itemCount': this.itemCount_ || 1 };
    },

    loadExtraState: function (state) {
        this.itemCount_ = state ? (state['itemCount'] || 1) : 1;
        this.updateShape_();
    },

    decompose: function (workspace) {
        const containerBlock = workspace.newBlock('title_text_container');
        containerBlock.initSvg();
        let connection = containerBlock.getInput('STACK').connection;
        for (let i = 0; i < this.itemCount_; i++) {
            const itemBlock = workspace.newBlock('title_text_item');
            itemBlock.initSvg();
            connection.connect(itemBlock.previousConnection);
            connection = itemBlock.nextConnection;
        }
        return containerBlock;
    },

    compose: function (containerBlock) {
        let itemBlock = containerBlock.getInputTargetBlock('STACK');
        const connections = [];
        while (itemBlock && !itemBlock.isInsertionMarker()) {
            connections.push(itemBlock.valueConnection_);
            itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
        }
        this.itemCount_ = connections.length;
        this.updateShape_();
        this.saveTextData_();
    },

    saveConnections: function (containerBlock) {
        let itemBlock = containerBlock.getInputTargetBlock('STACK');
        let i = 0;
        while (itemBlock && !itemBlock.isInsertionMarker()) {
            const input = this.getInput('ADD' + i);
            itemBlock.valueConnection_ = input && input.connection.targetConnection;
            i++;
            itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
        }
    },

    updateShape_: function () {
        if (!this.getField('TEXT_DATA')) {
            const dummyInput = this.appendDummyInput('DUMMY_TEXT_DATA');
            const hiddenField = new Blockly.FieldTextInput('[]');
            dummyInput.appendField(hiddenField, 'TEXT_DATA');
            dummyInput.setVisible(false);
            hiddenField.setVisible(false);
        }

        for (let i = 0; this.getInput('ADD' + i); i++) {
            this.removeInput('ADD' + i);
        }
        
        for (let i = 0; i < this.itemCount_; i++) {
            const input = this.appendValueInput('ADD' + i)
                .setCheck('String')
                .setAlign(Blockly.Input.Align.RIGHT);
            if (i === 0) {
                input.appendField("with text");
            } else {
                input.appendField("+");
            }
        }
    }
}, undefined, ['title_text_item']);
Blockly.Blocks['launch_blocks_container'] = {
    init: function () {
        this.appendDummyInput().appendField("Blocks to Ignore");
        this.appendStatementInput('STACK');
        this.setColour('#ad9d4b');
        this.contextMenu = false;
    }
};

Blockly.Blocks['launch_blocks_item'] = {
    init: function () {
        this.appendDummyInput().appendField("Ignore Block");
        this.setPreviousStatement(true);
        this.setNextStatement(true);
        this.setColour('#ad9d4b');
        this.contextMenu = false;
    }
};

Blockly.Extensions.register('launch_blocks_init', function () {
    this.inputCount_ = 0;
    if (!this.getField('IGNORE_DATA')) {
        const input = this.appendDummyInput('DUMMY_IGNORE_DATA');
        const field = new Blockly.FieldTextInput('[]');
        input.appendField(field, 'IGNORE_DATA');
        input.setVisible(false);
        field.setVisible(false);
    }
    this.updateShape_();
});

Blockly.Extensions.registerMutator('launch_blocks_mutator', {
    saveIgnoreData_: function () {
        const ignoreData = [];
        for (let i = 0; i < (this.inputCount_ || 0); i++) {
            const blockName = this.getFieldValue('BLOCK' + i) || '';
            ignoreData.push({ blockName: blockName });
        }
        if (this.getField('IGNORE_DATA')) {
            this.setFieldValue(JSON.stringify(ignoreData), 'IGNORE_DATA');
        }
    },

    mutationToDom: function () {
        this.saveIgnoreData_();
        const container = document.createElement('mutation');
        container.setAttribute('ignores', this.inputCount_ || 0);
        return container;
    },

    domToMutation: function (xmlElement) {
        this.inputCount_ = isNaN(xmlElement.getAttribute('ignores')) ?
            0 : parseInt(xmlElement.getAttribute('ignores'), 10);
        this.updateShape_();
    },

    saveExtraState: function () {
        this.saveIgnoreData_();
        return { 'inputCount': this.inputCount_ || 0 };
    },

    loadExtraState: function (state) {
        this.inputCount_ = state ? (state['inputCount'] || 0) : 0;
        this.updateShape_();
    },

    decompose: function (workspace) {
        const containerBlock = workspace.newBlock('launch_blocks_container');
        containerBlock.initSvg();
        let connection = containerBlock.getInput('STACK').connection;
        for (let i = 0; i < this.inputCount_; i++) {
            const itemBlock = workspace.newBlock('launch_blocks_item');
            itemBlock.initSvg();
            connection.connect(itemBlock.previousConnection);
            connection = itemBlock.nextConnection;
        }
        return containerBlock;
    },

    compose: function (containerBlock) {
        let itemBlock = containerBlock.getInputTargetBlock('STACK');
        const connections = [];
        while (itemBlock && !itemBlock.isInsertionMarker()) {
            connections.push(itemBlock.valueConnection_);
            itemBlock = itemBlock.nextConnection && itemBlock.nextConnection.targetBlock();
        }
        this.inputCount_ = connections.length;
        this.updateShape_();
        this.saveIgnoreData_();
    },

    saveConnections: function (containerBlock) {
    },

    updateShape_: function () {
        if (!this.getField('IGNORE_DATA')) {
            const dummyInput = this.appendDummyInput('DUMMY_IGNORE_DATA');
            const hiddenField = new Blockly.FieldTextInput('[]');
            dummyInput.appendField(hiddenField, 'IGNORE_DATA');
            dummyInput.setVisible(false);
            hiddenField.setVisible(false);
        }

        let SelectorClass = null;
        if (typeof FieldMCItemSelector !== 'undefined') {
            SelectorClass = FieldMCItemSelector;
        } else if (Blockly.fieldRegistry && typeof Blockly.fieldRegistry.getClass === 'function') {
            SelectorClass = Blockly.fieldRegistry.getClass('field_mcitem_selector');
        } else if (Blockly.fieldRegistry && Blockly.fieldRegistry.registry_ && Blockly.fieldRegistry.registry_['field_mcitem_selector']) {
            SelectorClass = Blockly.fieldRegistry.registry_['field_mcitem_selector'];
        }

        for (let i = 0; i < this.inputCount_; i++) {
            if (!this.getInput('IGNORE_ROW' + i)) {
                const inputRow = this.appendDummyInput('IGNORE_ROW' + i)
                    .setAlign(Blockly.ALIGN_RIGHT)
                    .appendField(i === 0 ? "ignore block" : "and block");

                if (SelectorClass) {
                    inputRow.appendField(new SelectorClass('block'), 'BLOCK' + i);
                } else {
                    inputRow.appendField(new Blockly.FieldTextInput('CUSTOM:stone'), 'BLOCK' + i);
                }
            }
        }
        for (let i = this.inputCount_; this.getInput('IGNORE_ROW' + i); i++) {
            this.removeInput('IGNORE_ROW' + i);
        }
    }
}, undefined, ['launch_blocks_item']);