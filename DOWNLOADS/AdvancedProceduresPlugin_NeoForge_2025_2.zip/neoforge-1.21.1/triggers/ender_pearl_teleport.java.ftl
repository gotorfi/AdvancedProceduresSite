<#include "procedures.java.ftl">
@EventBusSubscriber public class ${name}Procedure {
	@SubscribeEvent public static void onEnderPearlLand(net.neoforged.neoforge.event.entity.EntityTeleportEvent.EnderPearl event) {
		if (event != null && event.getEntity() != null) {
			if (event.isCanceled()) {
				return;
			}
			if (event.getPearlEntity() == null) {
				return;
			}

			<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"x": "event.getTargetX()",
				"y": "event.getTargetY()",
				"z": "event.getTargetZ()",
				"world": "event.getEntity().level()",
				"entity": "event.getEntity()",
				"immediatesourceentity": "event.getPearlEntity()",
				"event": "event"
			}/>
			</#compress></#assign>
			execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
		}
	}