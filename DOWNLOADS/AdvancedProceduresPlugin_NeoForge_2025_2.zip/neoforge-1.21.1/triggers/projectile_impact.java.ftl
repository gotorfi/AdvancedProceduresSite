<#include "procedures.java.ftl">
@EventBusSubscriber public class ${name}Procedure {
	@SubscribeEvent public static void onProjectileImpact(net.neoforged.neoforge.event.entity.ProjectileImpactEvent event) {
		if (event != null && event.getProjectile() != null) {
			net.minecraft.world.phys.HitResult _hitResult = event.getRayTraceResult();
			net.minecraft.world.entity.Entity _targetEntity = null;

			double _x = _hitResult.getLocation().x;
			double _y = _hitResult.getLocation().y;
			double _z = _hitResult.getLocation().z;

			if (_hitResult instanceof net.minecraft.world.phys.EntityHitResult _entityHit) {
				_targetEntity = _entityHit.getEntity();
			} else if (_hitResult instanceof net.minecraft.world.phys.BlockHitResult _blockHit) {
				net.minecraft.core.BlockPos _bp = _blockHit.getBlockPos();
				_x = _bp.getX();
				_y = _bp.getY();
				_z = _bp.getZ();
			}

			<#assign dependenciesCode><#compress>
			<@procedureDependenciesCode dependencies, {
				"x": "_x",
				"y": "_y",
				"z": "_z",
				"world": "event.getProjectile().level()",
				"entity": "_targetEntity",
				"sourceentity": "event.getProjectile()",
				"event": "event"
			}/>
			</#compress></#assign>
			execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
		}
	}