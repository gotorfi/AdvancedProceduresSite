<#include "procedures.java.ftl">
@EventBusSubscriber public class ${name}Procedure {
	private static final java.util.Map<java.util.UUID, net.minecraft.world.item.ItemStack> LAST_CARRIED = new java.util.HashMap<>();

	@SubscribeEvent public static void onPlayerTick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post event) {
		net.minecraft.world.entity.player.Player _player = event.getEntity();
		if (_player != null && !_player.level().isClientSide()) {
			net.minecraft.world.item.ItemStack _currentCarried = _player.containerMenu.getCarried();
			net.minecraft.world.item.ItemStack _lastCarried = LAST_CARRIED.getOrDefault(_player.getUUID(), net.minecraft.world.item.ItemStack.EMPTY);

			if (!net.minecraft.world.item.ItemStack.matches(_currentCarried, _lastCarried)) {
				LAST_CARRIED.put(_player.getUUID(), _currentCarried.copy());

				<#assign dependenciesCode>
					<@procedureDependenciesCode dependencies, {
						"x": "_player.getX()",
						"y": "_player.getY()",
						"z": "_player.getZ()",
						"world": "_player.level()",
						"entity": "_player",
						"itemstack": "_currentCarried",
						"event": "event"
					}/>
				</#assign>
				execute(event<#if dependenciesCode?has_content>,</#if>${dependenciesCode});
			}
		}
	}