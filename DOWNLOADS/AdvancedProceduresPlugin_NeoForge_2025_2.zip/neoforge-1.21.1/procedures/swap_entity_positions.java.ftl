<#include "mcitems.ftl">
if (${input$entity1} instanceof net.minecraft.world.entity.Entity _ent1 && ${input$entity2} instanceof net.minecraft.world.entity.Entity _ent2) {
	net.minecraft.world.phys.Vec3 _pos1 = _ent1.position();
	net.minecraft.world.phys.Vec3 _pos2 = _ent2.position();

	_ent1.teleportTo(_pos2.x, _pos2.y, _pos2.z);
	_ent2.teleportTo(_pos1.x, _pos1.y, _pos1.z);

	if (_ent1 instanceof net.minecraft.server.level.ServerPlayer _player1) {
		_player1.connection.teleport(_pos2.x, _pos2.y, _pos2.z, _player1.getYRot(), _player1.getXRot());
	}
	if (_ent2 instanceof net.minecraft.server.level.ServerPlayer _player2) {
		_player2.connection.teleport(_pos1.x, _pos1.y, _pos1.z, _player2.getYRot(), _player2.getXRot());
	}
}