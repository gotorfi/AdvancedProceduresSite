if (${input$entity} instanceof net.minecraft.world.entity.Entity _ent) {
    float _newYaw = _ent.getYRot() + (float) ${input$degrees};
    _ent.setYRot(_newYaw);
    if (_ent instanceof net.minecraft.world.entity.LivingEntity _living) {
        _living.yHeadRot = _newYaw;
        _living.yBodyRot = _newYaw;
    }
}