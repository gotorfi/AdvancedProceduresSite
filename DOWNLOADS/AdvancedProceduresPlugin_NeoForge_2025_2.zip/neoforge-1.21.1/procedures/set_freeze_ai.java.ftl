if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    _mob.setNoAi(${input$state});
}
