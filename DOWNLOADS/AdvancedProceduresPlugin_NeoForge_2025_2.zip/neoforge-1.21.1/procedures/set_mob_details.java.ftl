<#assign mode = field$mode!"AGE">
if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _livingEntity) {
<#if mode == "AGE">
    boolean _isBaby = ((double) ${input$value}) <= 0.0;
    if (_livingEntity instanceof net.minecraft.world.entity.AgeableMob _ageable) {
        _ageable.setBaby(_isBaby);
    } else {
        try {
            java.lang.reflect.Method _setBaby = _livingEntity.getClass().getMethod("setBaby", boolean.class);
            _setBaby.invoke(_livingEntity, _isBaby);
        } catch (Exception _e) {
            // fail
        }
    }
<#elseif mode == "SCALE">
    double _scaleVal = Math.max(0.01D, (double) ${input$value});
    var _scaleAttr = _livingEntity.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.SCALE);
    if (_scaleAttr != null) {
        _scaleAttr.setBaseValue(_scaleVal);
    }
</#if>
}