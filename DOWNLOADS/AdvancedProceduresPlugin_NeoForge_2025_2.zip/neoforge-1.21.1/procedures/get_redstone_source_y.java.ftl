((double) (new Object() {
    public double getY(net.minecraft.world.level.LevelAccessor _world, double _x, double _y, double _z) {
        if (_world instanceof net.minecraft.world.level.Level _lvl) {
            net.minecraft.core.BlockPos _pos = net.minecraft.core.BlockPos.containing(_x, _y, _z);
            for (net.minecraft.core.Direction _dir : net.minecraft.core.Direction.values()) {
                net.minecraft.core.BlockPos _neighbor = _pos.relative(_dir);
                if (_lvl.getSignal(_neighbor, _dir.getOpposite()) > 0 || _lvl.getDirectSignal(_neighbor, _dir.getOpposite()) > 0) {
                    return (double) _neighbor.getY();
                }
            }
        }
        return _y;
    }
}.getY(world, ((Number) ${input$x}).doubleValue(), ((Number) ${input$y}).doubleValue(), ((Number) ${input$z}).doubleValue())))