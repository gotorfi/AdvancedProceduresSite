<#include "mcitems.ftl">
<#include "mcelements.ftl">
((java.util.function.Supplier<Boolean>) () -> {
	if (!(${input$target_entity} instanceof net.minecraft.world.entity.Entity _re) || _re.level() == null) {
		return false;
	}

	Object _rawRange = ${input$range};
	double _dist = _rawRange instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawRange));

	net.minecraft.world.phys.Vec3 _eyePos = _re.getEyePosition(1.0F);
	net.minecraft.world.phys.Vec3 _lookVec = _re.getViewVector(1.0F);
	net.minecraft.world.phys.Vec3 _endPos = _eyePos.add(_lookVec.scale(_dist));

	net.minecraft.world.phys.BlockHitResult _hit = _re.level().clip(new net.minecraft.world.level.ClipContext(
		_eyePos, _endPos,
		net.minecraft.world.level.ClipContext.Block.COLLIDER,
		net.minecraft.world.level.ClipContext.Fluid.NONE,
		_re
	));

	if (_hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
		net.minecraft.world.level.block.state.BlockState _bState = _re.level().getBlockState(_hit.getBlockPos());
		return _bState.is(${mappedBlockToBlock(input$block)});
	}
	return false;
}).get()