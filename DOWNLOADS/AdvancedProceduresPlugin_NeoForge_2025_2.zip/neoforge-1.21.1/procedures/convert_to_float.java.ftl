((float) ${input$value})
