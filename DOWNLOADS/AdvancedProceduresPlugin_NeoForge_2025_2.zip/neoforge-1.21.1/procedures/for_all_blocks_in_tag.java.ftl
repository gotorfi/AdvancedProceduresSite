<#include "mcitems.ftl">
<#assign tag_val = input$tag!"\"minecraft:beds\"">
<#assign radius_val = input$radius!"10">

if (world instanceof net.minecraft.world.level.LevelAccessor _world) {
	String _tagName${cbi} = ${tag_val};
	if (_tagName${cbi}.startsWith("#")) {
		_tagName${cbi} = _tagName${cbi}.substring(1);
	}
	net.minecraft.resources.ResourceLocation _tagLoc${cbi} = net.minecraft.resources.ResourceLocation.tryParse(_tagName${cbi});
	if (_tagLoc${cbi} != null) {
		net.minecraft.tags.TagKey<net.minecraft.world.level.block.Block> _blockTag${cbi} = 
			net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.BLOCK, _tagLoc${cbi});
			
		int _radius${cbi} = (int) Math.max(1, (double) ${radius_val});
		double _centerX${cbi} = (double) ${input$x};
		double _centerY${cbi} = (double) ${input$y};
		double _centerZ${cbi} = (double) ${input$z};

		net.minecraft.core.BlockPos _centerPos${cbi} = net.minecraft.core.BlockPos.containing(_centerX${cbi}, _centerY${cbi}, _centerZ${cbi});
		java.util.List<net.minecraft.core.BlockPos> _foundBlocks${cbi} = new java.util.ArrayList<>();

		for (int _sx${cbi} = -_radius${cbi}; _sx${cbi} <= _radius${cbi}; _sx${cbi}++) {
			for (int _sy${cbi} = -_radius${cbi}; _sy${cbi} <= _radius${cbi}; _sy${cbi}++) {
				for (int _sz${cbi} = -_radius${cbi}; _sz${cbi} <= _radius${cbi}; _sz${cbi}++) {
					double _x${cbi} = Math.floor(_centerX${cbi}) + _sx${cbi};
					double _y${cbi} = Math.floor(_centerY${cbi}) + _sy${cbi};
					double _z${cbi} = Math.floor(_centerZ${cbi}) + _sz${cbi};
					net.minecraft.core.BlockPos _pos${cbi} = net.minecraft.core.BlockPos.containing(_x${cbi}, _y${cbi}, _z${cbi});
					
					if (_pos${cbi}.distSqr(_centerPos${cbi}) <= _radius${cbi} * _radius${cbi}) {
						if (_world.getBlockState(_pos${cbi}).is(_blockTag${cbi})) {
							_foundBlocks${cbi}.add(_pos${cbi});
						}
					}
				}
			}
		}

		_foundBlocks${cbi}.sort((_p1, _p2) -> Double.compare(_p1.distSqr(_centerPos${cbi}), _p2.distSqr(_centerPos${cbi})));

		for (net.minecraft.core.BlockPos _targetPos${cbi} : _foundBlocks${cbi}) {
			net.minecraft.world.phys.Vec3 vectoriterator = new net.minecraft.world.phys.Vec3(_targetPos${cbi}.getX() + 0.5D, _targetPos${cbi}.getY() + 0.5D, _targetPos${cbi}.getZ() + 0.5D);

			${statement$statement}
		}
	}
}