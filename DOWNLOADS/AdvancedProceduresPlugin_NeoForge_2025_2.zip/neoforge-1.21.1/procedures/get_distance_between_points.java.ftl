<#include "mcitems.ftl">
(new Object() {
	public double getDistance() {
		Object _rawX1 = ${input$x1};
		Object _rawY1 = ${input$y1};
		Object _rawZ1 = ${input$z1};
		Object _rawX2 = ${input$x2};
		Object _rawY2 = ${input$y2};
		Object _rawZ2 = ${input$z2};

		double _x1 = _rawX1 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX1));
		double _y1 = _rawY1 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY1));
		double _z1 = _rawZ1 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ1));

		double _x2 = _rawX2 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX2));
		double _y2 = _rawY2 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX2));
		double _z2 = _rawZ2 instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ2));

		double _dx = _x1 - _x2;
		double _dy = _y1 - _y2;
		double _dz = _z1 - _z2;

		return Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
	}
}.getDistance())