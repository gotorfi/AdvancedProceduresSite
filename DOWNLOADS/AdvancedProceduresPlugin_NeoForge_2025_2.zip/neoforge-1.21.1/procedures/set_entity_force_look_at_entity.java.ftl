if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob && ${input$target} instanceof net.minecraft.world.entity.Entity _target) {
    if (${input$state}) {
        _mob.getLookControl().setLookAt(_target, 30.0F, 30.0F);
        
        double _dx = _target.getX() - _mob.getX();
        double _dy = _target.getEyeY() - _mob.getEyeY();
        double _dz = _target.getZ() - _mob.getZ();
        double _dist = Math.sqrt(_dx * _dx + _dz * _dz);
        if (_dist >= 1.0E-7D) {
            float _yaw = (float) (Math.atan2(_dz, _dx) * (180.0D / Math.PI)) - 90.0F;
            float _pitch = (float) (-(Math.atan2(_dy, _dist) * (180.0D / Math.PI)));
            _mob.setYRot(_yaw);
            _mob.setXRot(_pitch);
            _mob.yHeadRot = _yaw;
            _mob.yBodyRot = _yaw;
        }
        
        _mob.goalSelector.getAvailableGoals().stream()
            .filter(_g -> _g.getGoal() instanceof net.minecraft.world.entity.ai.goal.RandomLookAroundGoal || _g.getGoal() instanceof net.minecraft.world.entity.ai.goal.LookAtPlayerGoal)
            .forEach(_g -> _mob.goalSelector.removeGoal(_g.getGoal()));
    } else {
        _mob.goalSelector.addGoal(8, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(_mob, net.minecraft.world.entity.player.Player.class, 8.0F));
        _mob.goalSelector.addGoal(8, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(_mob));
    }
}