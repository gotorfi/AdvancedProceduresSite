<#include "mcitems.ftl">
<#include "mcelements.ftl">
(${input$entity} instanceof net.minecraft.world.entity.Mob _mob && _mob.getTarget() != null ? _mob.getTarget().getType() == ${generator.map(field$type, "entities", 1)} : false)