if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _livingFreeze) {
    net.minecraft.world.entity.ai.attributes.AttributeInstance _attr = _livingFreeze.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
    if (_attr != null) {
        net.minecraft.resources.ResourceLocation _modId = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("${modid}", "freeze_movement");
        _attr.removeModifier(_modId);
        <#if input$state?? && (input$state == "true" || input$state == "TRUE")>
        _attr.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(
            _modId,
            -1.0d,
            net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
        ));
        </#if>
    }
}