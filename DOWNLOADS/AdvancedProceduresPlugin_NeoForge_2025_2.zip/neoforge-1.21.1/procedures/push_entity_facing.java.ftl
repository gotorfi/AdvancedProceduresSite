<#include "mcitems.ftl">
if (${input$target_entity} instanceof net.minecraft.world.entity.Entity _targetEnt && ${input$source_entity} instanceof net.minecraft.world.entity.Entity _sourceEnt) {
    double _power = <#if input$power?? && input$power?has_content>${input$power}<#else>1.0D</#if>;
    
    net.minecraft.world.phys.Vec3 _pushDir = _sourceEnt.getLookAngle().normalize();

    net.minecraft.world.phys.Vec3 _motion = _pushDir.scale(_power);
    
    _targetEnt.setDeltaMovement(_motion);
    _targetEnt.hurtMarked = true;
    if (_targetEnt instanceof net.minecraft.server.level.ServerPlayer _player) {
        _player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket(_targetEnt));
    }
}