<#assign targetVal = input$target!"0">
<#assign op = field$operator!"INC">
<#assign change = (op == "INC")?then("1", "-1")>
(new Object() {
    public double change(Object _obj) {
        if (_obj instanceof Integer _i) return _i + ${change};
        if (_obj instanceof Long _l) return _l + ${change};
        if (_obj instanceof Float _f) return _f + ${change}.0f;
        if (_obj instanceof Double _d) return _d + ${change}.0d;
        if (_obj instanceof Number _n) return _n.doubleValue() + ${change};
        return 0;
    }
}.change(${targetVal}))