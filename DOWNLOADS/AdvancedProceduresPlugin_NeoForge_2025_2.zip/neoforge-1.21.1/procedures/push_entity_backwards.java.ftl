if (${input$entity} instanceof net.minecraft.world.entity.Entity _ent) {
    net.minecraft.world.phys.Vec3 _backDir = _ent.getLookAngle().reverse();
    double _speed = ${input$speed};
    double _dist = ${input$distance};
    
    double _power = ${input$sine} ? (_speed * (_dist * 0.5d)) : _speed;
    
    net.minecraft.world.phys.Vec3 _motion = _backDir.scale(_power);
    
    _ent.setDeltaMovement(_motion);
    _ent.hurtMarked = true;

    if (_ent instanceof net.minecraft.server.level.ServerPlayer _player) {
        _player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket(_ent));
    }
}