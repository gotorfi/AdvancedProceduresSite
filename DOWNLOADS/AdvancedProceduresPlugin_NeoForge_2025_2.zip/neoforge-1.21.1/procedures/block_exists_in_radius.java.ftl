<#include "mcelements.ftl">
<#include "mcitems.ftl">
(world instanceof net.minecraft.world.level.Level _level ? net.minecraft.core.BlockPos.betweenClosedStream(
    net.minecraft.core.BlockPos.containing((double) ${input$x}, (double) ${input$y}, (double) ${input$z}).offset(
        -(int)${input$radius}, -(int)${input$radius}, -(int)${input$radius}
    ),
    net.minecraft.core.BlockPos.containing((double) ${input$x}, (double) ${input$y}, (double) ${input$z}).offset(
        (int)${input$radius}, (int)${input$radius}, (int)${input$radius}
    )
).anyMatch(_pos -> _level.getBlockState(_pos).is(${mappedBlockToBlockStateCode(input$block)}.getBlock())) : false)