(${input$entity} != null && ${input$entity}.getDeltaMovement().horizontalDistanceSqr() > 0.001)
