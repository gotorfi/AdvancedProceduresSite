if (world instanceof ServerLevel _level) {
	AdvancementHolder _adv = _level.getServer().getAdvancements().get(net.minecraft.resources.ResourceLocation.parse(${input$advancement}));
	if (_adv != null) {
		for (ServerPlayer _player : _level.getServer().getPlayerList().getPlayers()) {
			AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
			if (_ap.isDone()) {
				for (String criteria : _ap.getCompletedCriteria())
					_player.getAdvancements().revoke(_adv, criteria);
			}
		}
	}
}