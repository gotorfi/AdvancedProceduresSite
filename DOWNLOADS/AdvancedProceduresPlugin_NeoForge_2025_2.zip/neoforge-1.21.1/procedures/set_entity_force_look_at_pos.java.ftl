if (${input$entity} instanceof net.minecraft.world.entity.Mob _mobLookTarget) {
    if (${input$state}) {
        double _tx = (double) ${input$x};
        double _ty = (double) ${input$y};
        double _tz = (double) ${input$z};
        
        _mobLookTarget.getLookControl().setLookAt(_tx, _ty, _tz, 30.0F, 30.0F);
        
        double _dx = _tx - _mobLookTarget.getX();
        double _dy = _ty - _mobLookTarget.getEyeY();
        double _dz = _tz - _mobLookTarget.getZ();
        double _dist = Math.sqrt(_dx * _dx + _dz * _dz);
        if (_dist >= 1.0E-7D) {
            float _yaw = (float) (Math.atan2(_dz, _dx) * (180.0D / Math.PI)) - 90.0F;
            float _pitch = (float) (-(Math.atan2(_dy, _dist) * (180.0D / Math.PI)));
            _mobLookTarget.setYRot(_yaw);
            _mobLookTarget.setXRot(_pitch);
            _mobLookTarget.yHeadRot = _yaw;
            _mobLookTarget.yBodyRot = _yaw;
        }
        
        _mobLookTarget.goalSelector.getAvailableGoals().stream()
            .filter(_g -> _g.getGoal() instanceof net.minecraft.world.entity.ai.goal.RandomLookAroundGoal || _g.getGoal() instanceof net.minecraft.world.entity.ai.goal.LookAtPlayerGoal)
            .forEach(_g -> _mobLookTarget.goalSelector.removeGoal(_g.getGoal()));
    } else {
        _mobLookTarget.goalSelector.addGoal(8, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(_mobLookTarget, net.minecraft.world.entity.player.Player.class, 8.0F));
        _mobLookTarget.goalSelector.addGoal(8, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(_mobLookTarget));
    }
}