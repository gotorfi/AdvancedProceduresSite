<#assign category = (field$category)?default("ALL")>
<#assign inc_empty = (field$include_empty!"false")?lower_case?boolean>

if (${input$var} != null) {
    int _startIdx${cbi} = 0;
    int _endIdx${cbi} = ${input$var}.size();

    <#if category == "HOTBAR">
        _startIdx${cbi} = 0;
        _endIdx${cbi} = Math.min(9, ${input$var}.size());
    <#elseif category == "INVENTORY">
        _startIdx${cbi} = 9;
        _endIdx${cbi} = Math.min(36, ${input$var}.size());
    <#elseif category == "ARMOR">
        _startIdx${cbi} = 36;
        _endIdx${cbi} = Math.min(40, ${input$var}.size());
    <#elseif category == "OFFHAND">
        _startIdx${cbi} = 40;
        _endIdx${cbi} = Math.min(41, ${input$var}.size());
    </#if>

    for (int _idx${cbi} = _startIdx${cbi}; _idx${cbi} < _endIdx${cbi}; _idx${cbi}++) {
        Object _obj${cbi} = ${input$var}.get(_idx${cbi});
        net.minecraft.world.item.ItemStack itemstackiterator = net.minecraft.world.item.ItemStack.EMPTY;
        
        if (_obj${cbi} instanceof net.minecraft.world.item.ItemStack _stack${cbi}) {
            itemstackiterator = _stack${cbi};
        }

        <#if !inc_empty>
        if (itemstackiterator.isEmpty())
            continue;
        </#if>

        int slotiterator = _idx${cbi};
        int amountiterator = itemstackiterator.getCount();

        ${statement$foreach}
    }
}