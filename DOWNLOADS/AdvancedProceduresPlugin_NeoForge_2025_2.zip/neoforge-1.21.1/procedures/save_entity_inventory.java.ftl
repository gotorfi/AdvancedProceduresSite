<#assign inc_hotbar = field$include_hotbar?lower_case?boolean>
<#assign inc_inventory = field$include_inventory?lower_case?boolean>
<#assign inc_armor = (field$include_armor!"true")?lower_case?boolean>
<#assign inc_offhand = field$include_offhand?lower_case?boolean>

if (${input$entity} instanceof net.minecraft.world.entity.player.Player _player) {
    ${input$var}.clear();

    for (int _i = 0; _i < 41; _i++) {
        ${input$var}.add(net.minecraft.world.item.ItemStack.EMPTY);
    }
    
    <#if inc_hotbar>
    for (int _slot = 0; _slot < 9; _slot++) {
        net.minecraft.world.item.ItemStack _stack = _player.getInventory().getItem(_slot);
        ${input$var}.set(_slot, _stack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _stack.copy());
    }
    </#if>

    <#if inc_inventory>
    for (int _slot = 9; _slot < 36; _slot++) {
        net.minecraft.world.item.ItemStack _stack = _player.getInventory().getItem(_slot);
        ${input$var}.set(_slot, _stack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _stack.copy());
    }
    </#if>

    <#if inc_armor>
    for (int _slot = 0; _slot < 4; _slot++) {
        net.minecraft.world.item.ItemStack _stack = _player.getInventory().getItem(36 + _slot);
        ${input$var}.set(36 + _slot, _stack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _stack.copy());
    }
    </#if>

    <#if inc_offhand>
    net.minecraft.world.item.ItemStack _offstack = _player.getOffhandItem();
    ${input$var}.set(40, _offstack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _offstack.copy());
    </#if>
} else if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity _living) {
    ${input$var}.clear();
    
    <#if inc_hotbar || inc_inventory>
    if (_living.getCapability(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.ENTITY, null) instanceof net.neoforged.neoforge.items.IItemHandler _itemHandler) {
        int _maxSlots = _itemHandler.getSlots();
        <#if !inc_inventory && inc_hotbar>
            _maxSlots = Math.min(_maxSlots, 9);
        </#if>
        for (int _idx = 0; _idx < _maxSlots; _idx++) {
            net.minecraft.world.item.ItemStack _stack = _itemHandler.getStackInSlot(_idx);
            ${input$var}.add(_stack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _stack.copy());
        }
    }
    </#if>

    <#if inc_armor>
    net.minecraft.world.entity.EquipmentSlot[] _armorSlots = new net.minecraft.world.entity.EquipmentSlot[]{
        net.minecraft.world.entity.EquipmentSlot.FEET,
        net.minecraft.world.entity.EquipmentSlot.LEGS,
        net.minecraft.world.entity.EquipmentSlot.CHEST,
        net.minecraft.world.entity.EquipmentSlot.HEAD
    };
    for (net.minecraft.world.entity.EquipmentSlot _slot : _armorSlots) {
        net.minecraft.world.item.ItemStack _astack = _living.getItemBySlot(_slot);
        ${input$var}.add(_astack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _astack.copy());
    }
    </#if>

    <#if inc_offhand>
    net.minecraft.world.item.ItemStack _ostack = _living.getOffhandItem();
    ${input$var}.add(_ostack.isEmpty() ? net.minecraft.world.item.ItemStack.EMPTY : _ostack.copy());
    </#if>
}