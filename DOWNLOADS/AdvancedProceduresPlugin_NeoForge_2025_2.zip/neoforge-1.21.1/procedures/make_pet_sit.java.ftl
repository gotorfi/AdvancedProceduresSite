<#assign action = field$action!"SIT">
if (${input$entity} instanceof net.minecraft.world.entity.TamableAnimal _tamable) {
    _tamable.setOrderedToSit(<#if action == "SIT">true<#else>false</#if>);
}