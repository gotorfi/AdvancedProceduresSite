<#include "mcitems.ftl">
if (${input$entity} instanceof net.minecraft.world.entity.player.Player _player && world instanceof net.minecraft.world.level.Level _lvl) {
    net.minecraft.world.item.ItemStack _result = ${mappedMCItemToItemStackCode(input$item, 1)};

    if (!_result.isEmpty()) {
        net.minecraft.core.component.DataComponentType<net.minecraft.world.item.enchantment.ItemEnchantments> _enchantmentComponent =
            net.minecraft.core.component.DataComponents.ENCHANTMENTS;

        net.minecraft.world.item.enchantment.ItemEnchantments _currentEnchants =
            _result.getOrDefault(_enchantmentComponent,
                net.minecraft.world.item.enchantment.ItemEnchantments.EMPTY);

        net.minecraft.world.item.enchantment.ItemEnchantments.Mutable _mutableEnchants =
            new net.minecraft.world.item.enchantment.ItemEnchantments.Mutable(_currentEnchants);

        <#if field$ENCHANT_DATA?? && field$ENCHANT_DATA?has_content && field$ENCHANT_DATA != "[]">
        <#assign enchants = field$ENCHANT_DATA?eval />
        <#list enchants as item>
        <#if item.ench?has_content>
        {
            var _enchHolder${item?index} = _lvl.registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                .get(net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.ENCHANTMENT,
                    net.minecraft.resources.ResourceLocation.parse("${item.ench?lower_case}")
                ));

            if (_enchHolder${item?index}.isPresent()) {
                int _levelTarget${item?index} = Math.max(1, (int) ${item.lvl!1});

                <#if item.rand?? && item.rand>
                if (_levelTarget${item?index} > 1) {
                    _levelTarget${item?index} = net.minecraft.util.Mth.nextInt(
                        _lvl.getRandom(),
                        1,
                        _levelTarget${item?index}
                    );
                }
                </#if>

                _mutableEnchants.set(_enchHolder${item?index}.get(), _levelTarget${item?index});
            }
        }
        </#if>
        </#list>
        </#if>

        _result.set(_enchantmentComponent, _mutableEnchants.toImmutable());
        _player.getInventory().add(_result);
    }
}