if (${input$entity} != null) {
    ${input$entity}.setInvulnerable(${input$immunity});
}
