<#include "mcitems.ftl">
<#assign mode = field$mode!"STRONGEST">
(new Object() {
	public double getRedstoneSignal() {
		Object _rawX = ${input$x};
		Object _rawY = ${input$y};
		Object _rawZ = ${input$z};

		double _cx = net.minecraft.util.Mth.floor(_rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX)));
		double _cy = net.minecraft.util.Mth.floor(_rawY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY)));
		double _cz = net.minecraft.util.Mth.floor(_rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ)));

		net.minecraft.core.BlockPos _pos = net.minecraft.core.BlockPos.containing(_cx, _cy, _cz);

		<#if mode == "STRONGEST">
		return (double) world.getBestNeighborSignal(_pos);
		<#else>
		return (double) world.getDirectSignalTo(_pos);
		</#if>
	}
}.getRedstoneSignal())