if (${input$entity} != null && ${input$target} != null) {
	net.minecraft.world.entity.Entity _attacker${cbi} = ${input$entity};
	net.minecraft.world.entity.Entity _target${cbi} = ${input$target};

	double _localX${cbi} = (double) ${input$x};
	double _localY${cbi} = (double) ${input$y};
	double _localZ${cbi} = (double) ${input$z};

	net.minecraft.world.phys.Vec3 _lookVec${cbi} = _target${cbi}.getLookAngle();
	
	net.minecraft.world.phys.Vec3 _rightVec${cbi} = _lookVec${cbi}.cross(new net.minecraft.world.phys.Vec3(0, 1, 0)).normalize();
	
	double _targetX${cbi} = _target${cbi}.getX() + (_rightVec${cbi}.x * _localX${cbi}) + (_lookVec${cbi}.x * _localZ${cbi});
	double _targetY${cbi} = _target${cbi}.getY() + _localY${cbi};
	double _targetZ${cbi} = _target${cbi}.getZ() + (_rightVec${cbi}.z * _localX${cbi}) + (_lookVec${cbi}.z * _localZ${cbi});

	_attacker${cbi}.teleportTo(_targetX${cbi}, _targetY${cbi}, _targetZ${cbi});

	net.minecraft.world.phys.Vec3 _targetEyePos${cbi} = _target${cbi}.getEyePosition();
	_attacker${cbi}.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, _targetEyePos${cbi});
}