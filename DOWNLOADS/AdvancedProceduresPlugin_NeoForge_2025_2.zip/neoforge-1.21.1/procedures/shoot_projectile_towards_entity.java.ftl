{
    if (world instanceof net.minecraft.world.level.Level _level) {
        net.minecraft.world.level.Level projectileLevel = _level;
        
        double _custom_x = (double) ${input$x};
        double _custom_y = (double) ${input$y};
        double _custom_z = (double) ${input$z};
        <#assign targetCode = input$target />
        <#assign targetCode = targetCode?replace(", x, y, z,", ", _custom_x, _custom_y, _custom_z,") />
        
        net.minecraft.world.entity.Entity _targetEntity = ${targetCode};

        if (_targetEntity != null && ${input$projectile} instanceof net.minecraft.world.entity.projectile.Projectile _proj) {
            double _dx = _targetEntity.getX() - _custom_x;
            double _dy = _targetEntity.getEyeY() - 0.1d - _custom_y;
            double _dz = _targetEntity.getZ() - _custom_z;
            
            double _dist = Math.sqrt(_dx * _dx + _dy * _dy + _dz * _dz);
            if (_dist >= 1.0E-7D) {
                double _spawnX = _custom_x + (_dx / _dist) * 1.0d;
                double _spawnY = _custom_y + (_dist / _dist) * 1.0d;
                _spawnY = _custom_y + (_dy / _dist) * 1.0d;
                double _spawnZ = _custom_z + (_dz / _dist) * 1.0d;
                
                _proj.setPos(_spawnX, _spawnY, _spawnZ);
                _proj.shoot(_dx, _dy, _dz, (float) ${input$speed}, (float) ${input$inaccuracy});
                _level.addFreshEntity(_proj);
            }
        }
    }
}