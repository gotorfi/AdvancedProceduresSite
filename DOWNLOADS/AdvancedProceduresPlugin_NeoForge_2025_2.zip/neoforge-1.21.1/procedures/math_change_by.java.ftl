<#assign targetVal = input$target!"0">
<#assign amountVal = input$value!"0">
<#assign op = field$operator!"ADD">
<#assign sign = (op == "ADD")?then("+", "-")>
(new Object() {
    public double changeBy(Object _base, Object _val) {
        double _v = (_val instanceof Number _n) ? _n.doubleValue() : 0.0D;
        if (_base instanceof Integer _i) return _i ${sign} (int) _v;
        if (_base instanceof Long _l) return _l ${sign} (long) _v;
        if (_base instanceof Float _f) return _f ${sign} (float) _v;
        if (_base instanceof Double _d) return _d ${sign} _v;
        if (_base instanceof Number _n) return _n.doubleValue() ${sign} _v;
        return 0;
    }
}.changeBy(${targetVal}, ${amountVal}))