new Object() {
    public double evaluate(net.minecraft.world.entity.Entity _ent) {
        if (_ent instanceof net.minecraft.world.entity.player.Player _playerInv) {
            net.minecraft.world.entity.player.Inventory _inventory = _playerInv.getInventory();
            String _mode = "${field$inv_mode}";
            
            if ("HOTBAR".equals(_mode)) {
                for (int _i = 0; _i < 9; _i++) {
                    if (_inventory.getItem(_i).isEmpty()) {
                        return (double) _i;
                    }
                }
            } else if ("INVENTORY".equals(_mode)) {
                for (int _i = 9; _i < 36; _i++) {
                    if (_inventory.getItem(_i).isEmpty()) {
                        return (double) (_i - 9);
                    }
                }
            }
        }
        return 999.0d;
    }
}.evaluate(${input$entity})