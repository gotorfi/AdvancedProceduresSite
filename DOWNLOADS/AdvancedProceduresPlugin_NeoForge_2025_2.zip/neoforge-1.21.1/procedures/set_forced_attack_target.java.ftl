if (${input$source} instanceof net.minecraft.world.entity.PathfinderMob _mob && ${input$target} instanceof net.minecraft.world.entity.LivingEntity _targetEnt) {
    _mob.setTarget(_targetEnt);
    boolean _hasCustomAttack = false;
    for (net.minecraft.world.entity.ai.goal.WrappedGoal _goal : _mob.goalSelector.getAvailableGoals()) {
        if (_goal.getGoal().getClass().getName().contains("AnonymousCustomMelee")) {
            _hasCustomAttack = true;
            break;
        }
    }

    if (!_hasCustomAttack) {
        final float _dmgValue = (float) ${input$power};
        
        _mob.goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.Goal() {
            private final net.minecraft.world.entity.PathfinderMob mob = _mob;
            private final double speedModifier = 1.25D;
            private final float damage = _dmgValue;
            private int attackTicks = 0;
            {
                this.setFlags(java.util.EnumSet.of(net.minecraft.world.entity.ai.goal.Goal.Flag.MOVE, net.minecraft.world.entity.ai.goal.Goal.Flag.LOOK));
            }

            @Override
            public boolean canUse() {
                return this.mob.getTarget() != null && this.mob.getTarget().isAlive();
            }

            @Override
            public void start() {
                if (this.mob.getTarget() != null) {
                    this.mob.getNavigation().moveTo(this.mob.getTarget(), this.speedModifier);
                }
            }

            @Override
            public void stop() {
                this.mob.getNavigation().stop();
            }

            @Override
            public void tick() {
                net.minecraft.world.entity.LivingEntity target = this.mob.getTarget();
                if (target == null) return;

                this.mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
                if (this.mob.getRandom().nextInt(10) == 0) {
                    this.mob.getNavigation().moveTo(target, this.speedModifier);
                }

                if (this.attackTicks > 0) {
                    this.attackTicks--;
                }

                double distanceSq = this.mob.distanceToSqr(target.getX(), target.getY(), target.getZ());
                double attackReach = 2.0D * 2.0D; 

                if (distanceSq <= attackReach && this.attackTicks <= 0) {
                    this.attackTicks = 20;
                    this.mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                    target.hurt(this.mob.damageSources().mobAttack(this.mob), this.damage);
                }
            }

            @Override
            public String toString() {
                return "AnonymousCustomMelee";
            }
        });
    }
}