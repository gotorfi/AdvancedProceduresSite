<#include "mcitems.ftl">
<#assign mode = field$mode!"PULL">
if (${input$target_entity} instanceof net.minecraft.world.entity.Entity _centerEnt) {
    double _radius = <#if input$radius?? && input$radius?has_content>${input$radius}<#else>5.0D</#if>;
    double _power = <#if input$power?? && input$power?has_content>${input$power}<#else>1.0D</#if>;
    net.minecraft.world.phys.Vec3 _centerPos = _centerEnt.position();

    net.minecraft.world.phys.AABB _area = new net.minecraft.world.phys.AABB(_centerPos, _centerPos).inflate(_radius);
    for (net.minecraft.world.entity.Entity _ent : world.getEntitiesOfClass(net.minecraft.world.entity.Entity.class, _area)) {
        if (_ent != _centerEnt && _ent.position().distanceToSqr(_centerPos) <= _radius * _radius) {
            <#if mode == "PULL">
                net.minecraft.world.phys.Vec3 _vec = _centerPos.subtract(_ent.position());
            <#else>
                net.minecraft.world.phys.Vec3 _vec = _ent.position().subtract(_centerPos);
            </#if>

            if (_vec.lengthSqr() > 1.0E-4D) {
                net.minecraft.world.phys.Vec3 _motion = _vec.normalize().scale(_power);
                _ent.setDeltaMovement(_motion);
                _ent.hurtMarked = true;

                if (_ent instanceof net.minecraft.server.level.ServerPlayer _player) {
                    _player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket(_ent));
                }
            }
        }
    }
}