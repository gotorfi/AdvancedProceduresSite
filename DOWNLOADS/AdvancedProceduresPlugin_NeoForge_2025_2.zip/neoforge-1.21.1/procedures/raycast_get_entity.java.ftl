<#include "mcitems.ftl">
<#include "mcelements.ftl">
((java.util.function.Supplier<Boolean>) () -> {
	if (!(${input$target_entity} instanceof net.minecraft.world.entity.Entity _re) || _re.level() == null) {
		return false;
	}

	Object _rawRange = ${input$range};
	double _dist = _rawRange instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawRange));

	net.minecraft.world.phys.Vec3 _eyePos = _re.getEyePosition(1.0F);
	net.minecraft.world.phys.Vec3 _lookVec = _re.getViewVector(1.0F);
	net.minecraft.world.phys.Vec3 _endPos = _eyePos.add(_lookVec.scale(_dist));

	net.minecraft.world.phys.AABB _searchBox = _re.getBoundingBox().expandTowards(_lookVec.scale(_dist)).inflate(1.0D);
	net.minecraft.world.phys.EntityHitResult _entityHit = null;
	double _closestDist = _dist * _dist;

	for (net.minecraft.world.entity.Entity _ent : _re.level().getEntities(_re, _searchBox, e -> !e.isSpectator() && e.isPickable())) {
		if (_ent.getType() == ${generator.map(field$type, "entities", 1)}) {
			net.minecraft.world.phys.AABB _aabb = _ent.getBoundingBox().inflate(_ent.getPickRadius());
			java.util.Optional<net.minecraft.world.phys.Vec3> _clip = _aabb.clip(_eyePos, _endPos);
			if (_clip.isPresent()) {
				double _d = _eyePos.distanceToSqr(_clip.get());
				if (_d < _closestDist) {
					_closestDist = _d;
					_entityHit = new net.minecraft.world.phys.EntityHitResult(_ent, _clip.get());
				}
			}
		}
	}

	return _entityHit != null;
}).get()