<#assign mode_val = field$mode!"NEAREST">
<#assign target_val = input$block_or_tag!"\"minecraft:dirt\"">
<#assign dist_val = input$distance!"10">

new Object() {
	public net.minecraft.world.phys.Vec3 getTargetBlock() {
		if (!(world instanceof net.minecraft.world.level.LevelAccessor _world))
			return null;

		String _inputStr = ${target_val};
		if (_inputStr == null || _inputStr.isEmpty()) return null;

		if (_inputStr.startsWith("#")) {
			_inputStr = _inputStr.substring(1);
		}

		net.minecraft.resources.ResourceLocation _resLoc = net.minecraft.resources.ResourceLocation.tryParse(_inputStr);
		if (_resLoc == null) return null;

		net.minecraft.world.level.block.Block _singleBlock = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getOptional(_resLoc).orElse(null);
		net.minecraft.tags.TagKey<net.minecraft.world.level.block.Block> _blockTag = 
			_singleBlock == null ? net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.BLOCK, _resLoc) : null;

		int _radius = (int) Math.max(1, (double) ${dist_val});
		double _centerX = (double) ${input$x};
		double _centerY = (double) ${input$y};
		double _centerZ = (double) ${input$z};
		
		net.minecraft.world.phys.Vec3 _centerVec = new net.minecraft.world.phys.Vec3(_centerX, _centerY, _centerZ);
		net.minecraft.world.phys.Vec3 _resultVec = null;
		<#if mode_val == "NEAREST">
		double _bestDistSq = Double.MAX_VALUE;
		<#else>
		double _bestDistSq = -1.0;
		</#if>

		for (int _sx = -_radius; _sx <= _radius; _sx++) {
			for (int _sy = -_radius; _sy <= _radius; _sy++) {
				for (int _sz = -_radius; _sz <= _radius; _sz++) {
					double x = Math.floor(_centerX) + _sx;
					double y = Math.floor(_centerY) + _sy;
					double z = Math.floor(_centerZ) + _sz;
					
					net.minecraft.core.BlockPos _pos = net.minecraft.core.BlockPos.containing(x, y, z);
					net.minecraft.world.level.block.state.BlockState _currentState = _world.getBlockState(_pos);

					boolean _matches = false;
					if (_singleBlock != null) {
						if (_currentState.is(_singleBlock)) _matches = true;
					} else if (_blockTag != null) {
						if (_currentState.is(_blockTag)) _matches = true;
					}

					if (_matches) {
						net.minecraft.world.phys.Vec3 _currentVec = new net.minecraft.world.phys.Vec3(x + 0.5D, y + 0.5D, z + 0.5D);
						double _distSq = _centerVec.distanceToSqr(_currentVec);

						<#if mode_val == "NEAREST">
						if (_distSq < _bestDistSq) {
							_bestDistSq = _distSq;
							_resultVec = _currentVec;
						}
						<#else>
						if (_distSq > _bestDistSq) {
							_bestDistSq = _distSq;
							_resultVec = _currentVec;
						}
						</#if>
					}
				}
			}
		}
		return _resultVec;
	}
}.getTargetBlock()