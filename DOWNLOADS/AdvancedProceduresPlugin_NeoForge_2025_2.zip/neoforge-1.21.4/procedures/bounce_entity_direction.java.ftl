if (${input$entity} instanceof net.minecraft.world.entity.Entity _ent) {
    double _blocks = ${input$blocks};
    double _speed = ${input$speed};
    double _dx = 0;
    double _dz = 0;

    <#if field$direction == "NORTH">
    _dz = -1;
    <#elseif field$direction == "SOUTH">
    _dz = 1;
    <#elseif field$direction == "EAST">
    _dx = 1;
    <#elseif field$direction == "WEST">
    _dx = -1;
    <#elseif field$direction == "SOUTHEAST">
    _dx = 0.7071d; _dz = 0.7071d;
    <#elseif field$direction == "SOUTHWEST">
    _dx = -0.7071d; _dz = 0.7071d;
    <#elseif field$direction == "NORTHWEST">
    _dx = -0.7071d; _dz = -0.7071d;
    <#elseif field$direction == "NORTHEAST">
    _dx = 0.7071d; _dz = -0.7071d;
    </#if>

    double _multiplier = _speed * (_blocks * 0.3d);
    double _dy = Math.min(_blocks * 0.15d, 1.5d);

    _ent.setDeltaMovement(new net.minecraft.world.phys.Vec3(_dx * _multiplier, _dy, _dz * _multiplier));
    _ent.hurtMarked = true;
    _ent.hasImpulse = true;
}