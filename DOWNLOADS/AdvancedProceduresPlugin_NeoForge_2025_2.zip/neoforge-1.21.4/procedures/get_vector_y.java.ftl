(${input$vector} != null ? ${input$vector}.y : 0.0d)
