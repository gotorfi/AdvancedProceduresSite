if (${input$player} instanceof net.minecraft.server.level.ServerPlayer _player) {
    net.minecraft.resources.ResourceLocation _id = net.minecraft.resources.ResourceLocation.parse(${input$advancement});
    net.minecraft.advancements.AdvancementHolder _adv = _player.getServer().getAdvancements().get(_id);
    if (_adv != null) {
        net.minecraft.advancements.AdvancementProgress _progress = _player.getAdvancements().getOrStartProgress(_adv);
        if (_progress.hasProgress()) {
            for (String _criterion : _progress.getCompletedCriteria()) {
                _player.getAdvancements().revoke(_adv, _criterion);
            }
        }
    }
}