(${input$vector} != null ? ${input$vector}.z : 0.0d)
