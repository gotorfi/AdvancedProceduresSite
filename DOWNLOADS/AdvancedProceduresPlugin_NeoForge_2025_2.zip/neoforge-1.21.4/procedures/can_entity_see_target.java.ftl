(${input$entity} instanceof net.minecraft.world.entity.Mob _mob && _mob.getTarget() != null ? _mob.getSensing().hasLineOfSight(_mob.getTarget()) : false)
