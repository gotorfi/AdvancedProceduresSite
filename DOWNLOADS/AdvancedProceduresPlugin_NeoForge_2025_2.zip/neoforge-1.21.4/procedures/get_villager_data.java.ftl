<#include "mcitems.ftl">
<#assign dataType = field$data_type!"PROFESSION">
((java.util.function.Function<net.minecraft.world.entity.Entity, String>) _ent -> {
	if (_ent instanceof net.minecraft.world.entity.npc.Villager _villager) {
		net.minecraft.world.entity.npc.VillagerData _data = _villager.getVillagerData();
		<#if dataType == "PROFESSION">
			return net.minecraft.core.registries.BuiltInRegistries.VILLAGER_PROFESSION.getKey(_data.getProfession()).getPath();
		<#elseif dataType == "LEVEL_NUM">
			return String.valueOf(_data.getLevel());
		<#elseif dataType == "LEVEL_NAME">
			return switch (_data.getLevel()) {
				case 1 -> "novice";
				case 2 -> "apprentice";
				case 3 -> "journeyman";
				case 4 -> "expert";
				case 5 -> "master";
				default -> "unknown";
			};
		</#if>
	}
	return "";
}).apply(${input$entity})