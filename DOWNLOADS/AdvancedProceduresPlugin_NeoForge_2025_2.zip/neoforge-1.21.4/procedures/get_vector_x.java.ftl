(${input$vector} != null ? ${input$vector}.x : 0.0d)
