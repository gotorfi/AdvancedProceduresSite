(new Object() {
    public boolean check(net.minecraft.world.level.LevelAccessor _world) {
        if (_world instanceof net.minecraft.server.level.ServerLevel _level) {
            net.minecraft.resources.ResourceLocation _id = net.minecraft.resources.ResourceLocation.parse(${input$advancement});
            net.minecraft.advancements.AdvancementHolder _adv = _level.getServer().getAdvancements().get(_id);
            if (_adv != null) {
                java.util.List<net.minecraft.server.level.ServerPlayer> _players = _level.getServer().getPlayerList().getPlayers();
                if (_players.isEmpty()) return false;
                for (net.minecraft.server.level.ServerPlayer _player : _players) {
                    if (!_player.getAdvancements().getOrStartProgress(_adv).isDone()) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
}.check(world))