if (${input$entity} instanceof net.minecraft.world.entity.Mob _mob) {
    net.minecraft.resources.ResourceLocation _modifierId = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("${modid}", "brainless_stay");

    if (${input$state}) {
        _mob.goalSelector.removeAllGoals(_g -> true);
        _mob.targetSelector.removeAllGoals(_g -> true);
        _mob.getLookControl().setLookAt(_mob.getX(), _mob.getEyeY(), _mob.getZ(), 0.0F, 0.0F);
        
        if (${input$stay}) {
            _mob.setDeltaMovement(0.0d, _mob.getDeltaMovement().y, 0.0d);
            _mob.setXxa(0.0F);
            _mob.setYya(0.0F);
            _mob.setZza(0.0F);
            _mob.setSpeed(0.0F);

            net.minecraft.world.entity.ai.attributes.AttributeInstance _kb = _mob.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
            if (_kb != null) {
                _kb.removeModifier(_modifierId);

                _kb.addPermanentModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(
                    _modifierId, 
                    1.0D, 
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_VALUE
                ));
            }
            
            _mob.getPersistentData().putBoolean("BrainlessStayActive", true);
        }
    } else {
        _mob.goalSelector.removeAllGoals(_g -> true);
        _mob.targetSelector.removeAllGoals(_g -> true);

        net.minecraft.world.entity.ai.attributes.AttributeInstance _kb = _mob.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
        if (_kb != null) {
            _kb.removeModifier(_modifierId);
        }
        _mob.getPersistentData().putBoolean("BrainlessStayActive", false);
        
        try {
            java.lang.reflect.Method _m = net.minecraft.world.entity.Mob.class.getDeclaredMethod("registerGoals");
            _m.setAccessible(true);
            _m.invoke(_mob);
        } catch (Exception _e) {
            // fail
        }
    }
}