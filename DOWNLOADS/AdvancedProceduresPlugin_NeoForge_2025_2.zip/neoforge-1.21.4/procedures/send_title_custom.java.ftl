if (world instanceof net.minecraft.server.level.ServerLevel _servLvl) {
	StringBuilder _titleTextBuilder = new StringBuilder();

	<#if field$TEXT_DATA?? && field$TEXT_DATA?has_content && field$TEXT_DATA != "[]">
	<#assign textParts = field$TEXT_DATA?eval />
	<#list textParts as part>
	<#assign varName = "input$ADD" + part.index />
	<#if .vars[varName]?? && .vars[varName]?has_content && .vars[varName] != '""'>
	_titleTextBuilder.append(${.vars[varName]});
	</#if>
	</#list>
	</#if>

	String _titleText = _titleTextBuilder.toString();
	net.minecraft.network.chat.Component _comp = net.minecraft.network.chat.Component.literal(_titleText);
	int _fadeTicks = (int) (${input$fade} * 20.0D);
	int _holdTicks = (int) (${input$hold} * 20.0D);
	
	java.util.List<net.minecraft.server.level.ServerPlayer> _targetPlayers = new java.util.ArrayList<>();
	
	<#if field$TARGET == "ALL_PLAYERS">
	_targetPlayers.addAll(_servLvl.players());
	<#elseif field$TARGET == "CLOSEST_PLAYER">
	Object _rawX = ${input$x};
	Object _rawY = ${input$y};
	Object _rawZ = ${input$z};
	double _px = _rawX instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawX));
	double _py = _rawY instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawY));
	double _pz = _rawZ instanceof Number _n ? _n.doubleValue() : Double.parseDouble(String.valueOf(_rawZ));

	net.minecraft.world.entity.player.Player _closest = _servLvl.getNearestPlayer(net.minecraft.world.entity.ai.targeting.TargetingConditions.forNonCombat(), _px, _py, _pz);
	if (_closest instanceof net.minecraft.server.level.ServerPlayer _sp) {
		_targetPlayers.add(_sp);
	}
	</#if>
	
	for (net.minecraft.server.level.ServerPlayer _sp : _targetPlayers) {
		<#if field$TYPE == "ACTIONBAR">
		_sp.displayClientMessage(_comp, true);
		<#else>
		_sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(_fadeTicks, _holdTicks, _fadeTicks));
		<#if field$TYPE == "TITLE">
		_sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(_comp));
		<#elseif field$TYPE == "SUBTITLE">
		_sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(_comp));
		</#if>
		</#if>
	}
}