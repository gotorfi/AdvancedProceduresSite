(${input$entity} instanceof net.minecraft.world.entity.Mob _mob && _mob.getTarget() != null ? _mob.getTarget().position() : net.minecraft.world.phys.Vec3.ZERO)
