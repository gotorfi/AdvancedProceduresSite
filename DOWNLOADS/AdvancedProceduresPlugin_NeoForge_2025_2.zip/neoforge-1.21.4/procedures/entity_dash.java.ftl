if (${input$entity} instanceof net.minecraft.world.entity.Entity _ent) {
    double _power = ${input$power};
    net.minecraft.world.phys.Vec3 _motion;
    if (${input$head}) {
        _motion = _ent.getLookAngle().scale(_power);
    } else {
        double _yaw = Math.toRadians(_ent.getYRot());
        double _dx = -Math.sin(_yaw);
        double _dz = Math.cos(_yaw);
        _motion = new net.minecraft.world.phys.Vec3(_dx * _power, _ent.getDeltaMovement().y, _dz * _power);
    }
    _ent.setDeltaMovement(_motion);
    _ent.hurtMarked = true;
    _ent.hasImpulse = true;
    if (_ent instanceof net.minecraft.server.level.ServerPlayer _player) {
        _player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket(_ent));
    }
}