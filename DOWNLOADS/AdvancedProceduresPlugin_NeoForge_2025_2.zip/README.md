Advanced ProceduresDeveloped by GotorFI. © 2026 All Rights Reserved.  

This plugin is designed for compatibility with MCreator 2025.2 NeoForge 1.21.1 and 1.21.4.  

The primary objective of this plugin is to streamline and simplify the mod development process.   
If you encounter any anomalies, or if you would like to submit feature recommendations,   
please provide your bug reports and feedback via the following form:   
https://gotorfi.github.io/AdvancedProceduresSite/feedback.html   

IMPORTANT!
Since 2025.2 and below won't let you add external java files for procedure blocks, I had to remove some of the blocks to make this plugin work. Apologies!
If you want full access, please upgrade your MCreator version to 2025.3 or higher!

regards,  
GotorFI